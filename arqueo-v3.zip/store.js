// Datos de la app y las reglas del inventario (basadas en el modelo de Anturios).
// Todo movimiento es un registro: nada se borra; un error se anula con un movimiento contrario.

const NATIVE = !!window.Android;
const LS_STATE = 'arqueo.estado';
const LS_TURNO = 'arqueo.turno.';
const EPS = 0.0005;

let S = null;          // estado completo
let PROD = {};         // id -> producto
let ITEM = {};         // id -> ítem de la carta

// ---------- Utilidades ----------
const r4 = n => Math.round(n * 10000) / 10000;
const r2 = n => Math.round(n * 100) / 100;
const now = () => Date.now();
const pad = (n, l = 2) => String(n).padStart(l, '0');
function isoDay(t = Date.now()) {
  const d = new Date(t);
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
}
function hora(t) { const d = new Date(t); return pad(d.getHours()) + ':' + pad(d.getMinutes()); }
const DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
function fechaLarga(iso) {
  const [y, m, d] = iso.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  return DIAS[dt.getDay()] + ' ' + d + ' de ' + MESES[m - 1];
}
function fechaCorta(iso) {
  const [y, m, d] = iso.split('-').map(Number);
  return d + ' ' + MESES[m - 1].slice(0, 3);
}
function money(n) {
  const v = r2(n || 0);
  const [e, d] = Math.abs(v).toFixed(2).split('.');
  return (v < 0 ? '-$' : '$') + e.replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ',' + d;
}
function qty(n, dec = 2) {
  const v = Math.round((n || 0) * Math.pow(10, dec)) / Math.pow(10, dec);
  return String(v).replace('.', ',');
}
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function norm(s) { return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase(); }

// ---------- Unidades ----------
const UNITS = {
  botella: ['botella', 'botellas', 'bot.'],
  unidad: ['unidad', 'unidades', 'u.'],
  kg: ['kilo', 'kilos', 'kg'],
  paquete: ['paquete', 'paquetes', 'paq.'],
  funda: ['funda', 'fundas', 'funda'],
  lona: ['lona', 'lonas', 'lona'],
};
const LINE_UNITS = { oz: 'oz', und: 'und', cda: 'cda', g: 'g' };
function unitName(p, n) { const u = UNITS[p.unit] || [p.unit, p.unit, p.unit]; return Math.abs(n - 1) < EPS ? u[0] : u[1]; }
function unitShort(p) { return (UNITS[p.unit] || [p.unit, p.unit, p.unit])[2]; }
function ozPer(p) { const c = p.conv || {}; return c.oz || (c.und && c.ozPieza ? c.und * c.ozPieza : 0); }
// ¿Se cuenta por décimos? (botellas abiertas, pulpas, fundas de limón…)
function partial(p) { const c = p.conv || {}; return !!(ozPer(p) || c.und > 1 || c.cda || c.g) || p.unit === 'kg'; }

/** Cuántas unidades de conteo (botellas, fundas, kilos…) resta una línea de receta. null = no se puede convertir. */
function unitsFor(line, mult) {
  const p = PROD[line.p];
  if (!p) return null;
  let per;
  if (line.u === 'u') per = 1;
  else if (line.u === 'oz') per = ozPer(p);
  else if (line.u === 'und') per = (p.conv && p.conv.und) || 1;
  else per = p.conv && p.conv[line.u];
  if (!per) return null;
  return line.q * mult / per;
}
function lineText(line) {
  const p = PROD[line.p];
  if (!p) return qty(line.q) + ' ' + (LINE_UNITS[line.u] || '') + ' ' + (line.n || '');
  const u = line.u === 'u' ? unitName(p, line.q) : LINE_UNITS[line.u];
  return qty(line.q) + ' ' + u + ' de ' + p.name;
}
function stockText(p, v = p.stock) {
  return qty(v, partial(p) ? 2 : 2) + ' ' + unitShort(p);
}

// ---------- Ítems de la carta ----------
function itemLabel(it) { return it.variant ? it.name + ' · ' + it.variant.toLowerCase() : it.name; }
function itemPend(it) { return (it.pend || []).length > 0; }
function itemLow(it) {
  return (it.lines || []).some(l => {
    const p = PROD[l.p]; if (!p) return false;
    const need = unitsFor(l, 1);
    return need != null && p.stock + EPS < need;
  });
}

// ---------- Cargar y guardar ----------
function fresh() {
  const seed = JSON.parse(JSON.stringify(window.SEED));
  return {
    v: 1,
    created: now(),
    seedVersion: seed.version,
    settings: {
      responsable: '', pinHash: '', recovery: '', lockMin: 1, tema: 'oscuro', bar: 'Bar Monteselva', termsAccepted: 0, termsAt: 0,
      pricesOk: !!seed.settings.pricesOk, tragoOz: seed.settings.tragoOz, copaOz: seed.settings.copaOz,
    },
    seedFecha: seed.fecha || '',
    products: seed.products,
    items: seed.items,
    seq: { venta: 0, mov: 0, turno: 0, item: 0, prod: maxProdNum(seed.products) },
    turno: null,
    closed: [],
    setupDone: false,
  };
}

function maxProdNum(list) {
  return list.reduce((m, p) => { const n = /^P(\d+)$/.exec(p.id || ''); return n ? Math.max(m, +n[1]) : m; }, 0);
}

/**
 * Cuando Joseph manda un inventario base o una carta nueva (SEED.version mayor), se mezcla con lo que hay
 * en el celular sin borrar nada de ella:
 *  - si todavía no ha recibido ningún turno, toma el stock del Excel nuevo y la carta nueva;
 *  - si ya trabaja con la app, su stock manda (es lo que ella contó): solo se agregan productos e ítems nuevos.
 * Sus ajustes, PIN, fotos, precios que ella cambió e ítems que ella creó se conservan siempre.
 */
function mergeSeed() {
  const seed = window.SEED;
  if (!seed || !(seed.version > (S.seedVersion || 1))) return null;
  const used = S.closed.length > 0 || !!S.turno;
  const sp = JSON.parse(JSON.stringify(seed));
  const cur = {}; S.products.forEach(p => cur[p.id] = p);
  const oldSeedIds = new Set(S.products.filter(p => p.raw).map(p => p.id));
  // Se empareja por el nombre del Excel (raw). Si ya existe con otro código (renumerado antes), se usa ese.
  // Un producto creado por ella puede tener el mismo código que uno nuevo del Excel: el del Excel se renumera.
  const curByRaw = {};
  S.products.forEach(p => { if (p.raw) curByRaw[norm(p.raw)] = p; });
  let next = Math.max(S.seq.prod || 0, maxProdNum(S.products), maxProdNum(sp.products));
  const remap = {};
  sp.products.forEach(p => {
    const same = curByRaw[norm(p.raw || '')];
    const c = cur[p.id];
    let id = p.id;
    if (same) id = same.id;
    else if (c) id = 'P' + pad(++next, 3);
    if (id !== p.id) { remap[p.id] = id; p.id = id; }
  });
  const fix = id => remap[id] || id;
  sp.items.forEach(it => {
    if (it.group) it.group = fix(it.group);
    (it.lines || []).forEach(l => { if (l.p) l.p = fix(l.p); });
  });
  let added = 0, updated = 0, removed = 0;
  const seedIds = new Set(sp.products.map(p => p.id));
  sp.products.forEach(p => {
    const c = cur[p.id];
    if (!c) { S.products.push(p); added++; return; }
    if (!used) {
      if (Math.abs((c.stock || 0) - p.stock) > EPS) updated++;
      Object.assign(c, { stock: p.stock, name: p.name, slug: p.slug, cat: p.cat, unit: p.unit, conv: p.conv, pend: p.pend });
    }
  });
  if (!used) {
    // Productos del Excel viejo que ya no están (nadie los usó todavía)
    const before = S.products.length;
    S.products = S.products.filter(p => !oldSeedIds.has(p.id) || seedIds.has(p.id));
    removed = before - S.products.length;
  }
  const curItems = {}; S.items.forEach(i => curItems[i.id] = i);
  sp.items.forEach(it => {
    const c = curItems[it.id];
    if (!c) { S.items.push(it); return; }
    if (!used && !c.edited) {
      // Se conserva lo que ella eligió: precio cambiado a mano, ítem oculto, foto
      const keep = { active: c.active, img: c.img };
      if (c.priceEdited) keep.price = c.price;
      Object.assign(c, it);
      Object.keys(keep).forEach(k => { if (keep[k] !== undefined) c[k] = keep[k]; });
    }
  });
  const prodIds = new Set(S.products.map(p => p.id));
  S.items = S.items.filter(i => (i.lines || []).every(l => !l.p || prodIds.has(l.p)) && (!i.group || prodIds.has(i.group)));
  S.seq.prod = Math.max(next, maxProdNum(S.products));
  S.seedVersion = seed.version;
  S.seedFecha = seed.fecha || S.seedFecha || '';
  const news = { tipo: 'inventario', fecha: S.seedFecha, used, added, updated, removed };
  S.news = (S.news || []).concat([news]);
  return news;
}

function index() {
  PROD = {}; ITEM = {};
  S.products.forEach(p => PROD[p.id] = p);
  S.items.forEach(i => ITEM[i.id] = i);
}

function loadState() {
  let raw = '';
  try { raw = NATIVE ? Android.loadState() : (localStorage.getItem(LS_STATE) || ''); } catch (e) { raw = ''; }
  S = null;
  if (raw) { try { S = JSON.parse(raw); } catch (e) { S = null; } }
  if (!S || !S.products) S = fresh();
  S.settings = Object.assign(fresh().settings, S.settings || {});
  S.seq = Object.assign({ venta: 0, mov: 0, turno: 0, item: 0, prod: 0 }, S.seq || {});
  S.seq.prod = Math.max(S.seq.prod, maxProdNum(S.products));
  S.closed = S.closed || [];
  if (mergeSeed()) { index(); saveState(); }
  index();
}

function saveState() {
  const json = JSON.stringify(S);
  let ok = true;
  try {
    if (NATIVE) ok = Android.saveState(json);
    else localStorage.setItem(LS_STATE, json);
  } catch (e) { ok = false; }
  if (!ok) toast('No se pudo guardar. Revisa el espacio del celular.');
  return ok;
}

function loadTurnoFile(id) {
  try {
    const raw = NATIVE ? Android.loadTurno(id) : localStorage.getItem(LS_TURNO + id);
    return raw ? JSON.parse(raw) : null;
  } catch (e) { return null; }
}
function saveTurnoFile(t) {
  const json = JSON.stringify(t);
  if (NATIVE) return Android.saveTurno(t.id, json);
  if (localStorage.getItem(LS_TURNO + t.id)) return 'existe';
  try { localStorage.setItem(LS_TURNO + t.id, json); return 'ok'; } catch (e) { return 'error'; }
}
function listTurnoFiles() {
  if (NATIVE) { try { return JSON.parse(Android.listTurnos()); } catch (e) { return []; } }
  return Object.keys(localStorage).filter(k => k.startsWith(LS_TURNO)).map(k => k.slice(LS_TURNO.length)).sort();
}

// ---------- PIN ----------
async function sha(text) {
  if (NATIVE) return Android.sha256(text);
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}
const pinHash = pin => sha('arqueo|' + S.created + '|' + pin);
function newRecovery() {
  const abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let s = '';
  const rnd = crypto.getRandomValues(new Uint32Array(8));
  for (let i = 0; i < 8; i++) s += abc[rnd[i] % abc.length] + (i === 3 ? '-' : '');
  return s;
}

// ---------- Movimientos ----------
function by() { return S.settings.responsable || 'Bartender'; }

function addMov(t, pid, q, extra) {
  const p = PROD[pid];
  if (!p || Math.abs(q) < 1e-9) return null;
  const m = Object.assign({ id: 'M' + (++S.seq.mov), at: now(), t, p: pid, q: r4(q), by: by() }, extra || {});
  p.stock = r4(p.stock + m.q);
  S.turno.movs.push(m);
  return m;
}

/** Lo que resta del inventario vender `units` porciones de un ítem: [{p, q}] con q en unidades de conteo. */
function explode(it, units) {
  const out = {};
  (it.lines || []).forEach(l => {
    if (!l.p) return;
    const q = unitsFor(l, units);
    if (q == null) return;
    out[l.p] = (out[l.p] || 0) + q;
  });
  return Object.keys(out).map(p => ({ p, q: out[p] }));
}
function missingConv(it) { return (it.lines || []).filter(l => l.p && unitsFor(l, 1) == null).map(l => PROD[l.p] ? PROD[l.p].name : l.p); }

// ---------- Turno ----------
function openTurno(receivedFrom) {
  const date = isoDay();
  S.seq.turno++;
  const sameDay = S.closed.filter(c => c.date === date).length + 1;
  S.turno = {
    id: 'T' + date.replace(/-/g, '') + '-' + sameDay,
    n: S.seq.turno,
    date,
    openedAt: now(),
    by: by(),
    receivedFrom: (receivedFrom || '').trim(),
    sales: [], movs: [], counts: [], cortesias: [], ingresos: [], bajas: [],
    stockStart: snapshot(),
  };
  saveState();
  return S.turno;
}
function snapshot() { const o = {}; S.products.forEach(p => o[p.id] = p.stock); return o; }

function registerSale(comanda, lines) {
  const t = S.turno;
  const sale = { id: 'V' + pad(++S.seq.venta, 4), at: now(), comanda: String(comanda).trim(), by: by(), lines: [], total: 0 };
  lines.forEach(l => {
    const it = ITEM[l.item];
    if (!it || l.qty <= 0) return;
    const units = l.promo === '2x1' ? l.qty * 2 : l.qty;
    const total = r2(l.qty * it.price);
    sale.lines.push({ item: it.id, name: itemLabel(it), qty: l.qty, units, promo: l.promo || null, price: it.price, total });
    sale.total = r2(sale.total + total);
    const uso = it.cat === 'Cócteles';
    explode(it, units).forEach(x => addMov('venta', x.p, -x.q, { ref: sale.id, uso }));
  });
  t.sales.push(sale);
  saveState();
  return sale;
}

function voidSale(id, reason) {
  const t = S.turno;
  const sale = t.sales.find(s => s.id === id);
  if (!sale || sale.void) return;
  sale.void = { at: now(), reason: reason.trim(), by: by() };
  t.movs.filter(m => m.ref === id && m.t === 'venta').forEach(m => addMov('anulacion', m.p, -m.q, { ref: id, note: reason.trim() }));
  saveState();
}

/** kind: 'abrir' | 'cerrar'. counts: {pid: cantidad contada}. Lo no contado se queda como está. */
function saveCount(kind, counts) {
  const t = S.turno;
  const c = { id: 'K' + (t.counts.length + 1), kind, at: now(), by: by(), items: {} };
  Object.keys(counts).forEach(pid => {
    const p = PROD[pid]; if (!p) return;
    const calc = p.stock;
    const counted = r4(counts[pid]);
    c.items[pid] = [calc, counted];
    if (Math.abs(counted - calc) > EPS) addMov('conteo', pid, counted - calc, { ref: c.id, kind });
  });
  t.counts.push(c);
  if (kind === 'abrir') t.stockOpen = snapshot();
  saveState();
  return c;
}

function registerIngreso(lines, proveedor, firmo, note) {
  const t = S.turno;
  const ing = { id: 'I' + (t.ingresos.length + 1), at: now(), by: by(), proveedor: proveedor.trim(), firmo, note: (note || '').trim(), lines: [] };
  lines.forEach(l => {
    if (!PROD[l.p] || l.q <= 0) return;
    ing.lines.push({ p: l.p, q: l.q });
    addMov('ingreso', l.p, l.q, { ref: ing.id });
  });
  t.ingresos.push(ing);
  saveState();
  return ing;
}

const CORTESIA_TIPOS = {
  paquete: { label: 'Cortesía de paquete', firma: true, t: 'cortesia' },
  feriado: { label: 'Cortesía de feriado', firma: false, t: 'cortesia' },
  personal: { label: 'Consumo del personal', firma: false, t: 'consumo' },
};
function registerCortesia(tipo, lines, autoriza, firma, note) {
  const t = S.turno;
  const def = CORTESIA_TIPOS[tipo];
  const c = { id: 'C' + (t.cortesias.length + 1), at: now(), by: by(), tipo, autoriza: autoriza.trim(), firma: firma || '', note: (note || '').trim(), lines: [] };
  lines.forEach(l => {
    const it = ITEM[l.item]; if (!it || l.qty <= 0) return;
    c.lines.push({ item: it.id, name: itemLabel(it), qty: l.qty, price: it.price });
    explode(it, l.qty).forEach(x => addMov(def.t, x.p, -x.q, { ref: c.id }));
  });
  t.cortesias.push(c);
  saveState();
  return c;
}

const BAJA_MOTIVOS = { rotura: 'Rotura', merma: 'Merma', vencido: 'Vencido', derrame: 'Derrame' };
function registerBaja(pid, q, motivo, note) {
  const t = S.turno;
  const b = { id: 'B' + (t.bajas.length + 1), at: now(), by: by(), p: pid, q, motivo, note: (note || '').trim() };
  addMov('baja', pid, -q, { ref: b.id, motivo });
  t.bajas.push(b);
  saveState();
  return b;
}

// ---------- Resúmenes ----------
const MOV_LABEL = { venta: 'Venta', anulacion: 'Anulación', ingreso: 'Ingreso', cortesia: 'Cortesía', consumo: 'Consumo del personal', baja: 'Baja', conteo: 'Conteo' };

function summarize(t) {
  const live = t.sales.filter(s => !s.void);
  const byItem = {};
  live.forEach(s => s.lines.forEach(l => {
    const e = byItem[l.item] || (byItem[l.item] = { name: l.name, qty: 0, units: 0, total: 0 });
    e.qty += l.qty; e.units += l.units; e.total = r2(e.total + l.total);
  }));
  // Columnas como en su Excel: Ingresa, Sale (venta directa), Cortesía, Uso en el bar (cócteles), más bajas y conteo
  const byProd = {};
  t.movs.forEach(m => {
    const e = byProd[m.p] || (byProd[m.p] = { ingresa: 0, sale: 0, cortesia: 0, uso: 0, baja: 0, conteo: 0 });
    if (m.t === 'ingreso') e.ingresa += m.q;
    else if (m.t === 'venta' || m.t === 'anulacion') {
      const orig = m.t === 'venta' ? m : t.movs.find(x => x.ref === m.ref && x.t === 'venta' && x.p === m.p);
      if (orig && orig.uso) e.uso -= m.q; else e.sale -= m.q;
    } else if (m.t === 'cortesia' || m.t === 'consumo') e.cortesia -= m.q;
    else if (m.t === 'baja') e.baja -= m.q;
    else if (m.t === 'conteo') e.conteo += m.q;
  });
  Object.values(byProd).forEach(e => Object.keys(e).forEach(k => e[k] = r4(e[k])));
  const diffs = { abrir: 0, cerrar: 0 };
  t.counts.forEach(c => Object.values(c.items).forEach(([calc, counted]) => { if (Math.abs(counted - calc) > EPS) diffs[c.kind] = (diffs[c.kind] || 0) + 1; }));
  return {
    total: r2(live.reduce((a, s) => a + s.total, 0)),
    nSales: live.length,
    nVoid: t.sales.length - live.length,
    nCortesias: t.cortesias.length,
    nIngresos: t.ingresos.length,
    nBajas: t.bajas.length,
    diffs,
    byItem, byProd,
  };
}

function closeTurno(handedTo) {
  const t = S.turno;
  t.closedAt = now();
  t.handedTo = (handedTo || '').trim();
  t.stockEnd = snapshot();
  t.names = {};
  S.products.forEach(p => t.names[p.id] = [p.name, p.unit]);
  t.summary = summarize(t);
  t.pdf = 'Cierre-' + t.id + '.pdf';
  const r = saveTurnoFile(t);
  if (r === 'error') throw new Error('No se pudo guardar el turno');
  const s = t.summary;
  S.closed.push({
    id: t.id, date: t.date, openedAt: t.openedAt, closedAt: t.closedAt, receivedFrom: t.receivedFrom, handedTo: t.handedTo,
    total: s.total, nSales: s.nSales, nVoid: s.nVoid, nCortesias: s.nCortesias, diffs: s.diffs,
    byItem: s.byItem, byProd: s.byProd, pdf: t.pdf,
  });
  S.turno = null;
  saveState();
  return t;
}

// ---------- Respaldo ----------
function backupJson() {
  const turnos = {};
  listTurnoFiles().forEach(id => {
    const t = loadTurnoFile(id);
    if (t) turnos[id] = t;
  });
  return JSON.stringify({ app: 'arqueo-bar', v: 1, at: now(), state: S, turnos });
}
function restoreBackup(data) {
  if (!data || data.app !== 'arqueo-bar' || !data.state || !data.state.products) throw new Error('Ese archivo no es un respaldo de Arqueo Bar');
  Object.keys(data.turnos || {}).forEach(id => saveTurnoFile(data.turnos[id]));
  S = data.state;
  index();
  saveState();
}
