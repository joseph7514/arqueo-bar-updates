// Reporte de cierre: HTML blanco tamaño carta que se ve en la app y se convierte en PDF para WhatsApp.

function reportHtml(t) {
  const s = t.summary || summarize(t);
  const names = t.names || {};
  const nameOf = id => (names[id] ? names[id][0] : (PROD[id] ? PROD[id].name : id));
  const unitOf = id => { const u = names[id] ? names[id][1] : (PROD[id] ? PROD[id].unit : ''); return (UNITS[u] || [u, u, u])[2]; };
  const start = t.stockOpen || t.stockStart || {};
  const end = t.stockEnd || {};

  const items = Object.values(s.byItem).sort((a, b) => b.total - a.total);
  const countClose = (t.counts || []).filter(c => c.kind === 'cerrar').pop();
  const countOpen = (t.counts || []).filter(c => c.kind === 'abrir').pop();
  function diffRows(c) {
    if (!c) return '<tr><td colspan="4" class="muted">No se registró este conteo.</td></tr>';
    const rows = Object.keys(c.items).map(id => ({ id, calc: c.items[id][0], counted: c.items[id][1] })).filter(r => Math.abs(r.counted - r.calc) > EPS).sort((a, b) => (a.counted - a.calc) - (b.counted - b.calc));
    if (!rows.length) return '<tr><td colspan="4" class="ok">Todo lo contado cuadra.</td></tr>';
    return rows.map(r => '<tr><td>' + esc(nameOf(r.id)) + '</td><td class="n">' + qty(r.calc) + '</td><td class="n">' + qty(r.counted) + '</td><td class="n ' + (r.counted < r.calc ? 'bad' : 'warn') + '">' + (r.counted - r.calc > 0 ? '+' : '') + qty(r.counted - r.calc) + ' ' + esc(unitOf(r.id)) + '</td></tr>').join('');
  }

  // Movimientos del inventario con las columnas de su hoja de Excel
  const prodRows = S.products.map(p => {
    const e = s.byProd[p.id] || {};
    const movedAny = (e.ingresa || e.sale || e.cortesia || e.uso || e.baja || e.conteo);
    if (!movedAny) return '';
    return '<tr><td>' + esc(nameOf(p.id)) + '</td><td class="n">' + qty(start[p.id] != null ? start[p.id] : '') + '</td>' +
      ['ingresa', 'sale', 'cortesia', 'uso', 'baja'].map(k => '<td class="n">' + (e[k] ? qty(e[k]) : '') + '</td>').join('') +
      '<td class="n">' + (e.conteo ? (e.conteo > 0 ? '+' : '') + qty(e.conteo) : '') + '</td>' +
      '<td class="n">' + qty(end[p.id] != null ? end[p.id] : '') + '</td></tr>';
  }).filter(Boolean).join('');

  return '<!doctype html><html lang="es"><head><meta charset="utf-8"><style>' +
    '*{box-sizing:border-box}body{font:13px/1.45 -apple-system,Roboto,"Segoe UI",sans-serif;color:#15202b;margin:0;padding:16px}' +
    'h1{font-size:21px;margin:0 0 2px}h2{font-size:14px;margin:22px 0 7px;color:#9a6512;border-bottom:2px solid #f0d9ad;padding-bottom:3px}' +
    '.muted{color:#64748b}.sub{color:#64748b;font-size:12px}.chip{display:inline-block;background:#f3f4f7;border-radius:10px;padding:2px 9px;margin:1px 2px;font-size:12px}' +
    '.grid{display:flex;gap:10px;margin-top:10px}.box{flex:1;border:1px solid #e3e8ef;border-radius:10px;padding:9px 11px}.box .k{color:#64748b;font-size:11px}.box .v{font-size:20px;font-weight:800}' +
    'table{width:100%;border-collapse:collapse;margin-top:4px}th,td{text-align:left;padding:5px 6px;border-bottom:1px solid #eceff3;vertical-align:top}th{font-size:11px;text-transform:uppercase;letter-spacing:.04em;color:#64748b;background:#f8fafc}' +
    '.n{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}.bad{color:#c42b2b}.warn{color:#9a6512}.ok{color:#0e8a5f}' +
    'tr,.bloque{break-inside:avoid}.tot{font-weight:800}.foot{margin-top:22px;border-top:1px solid #e3e8ef;padding-top:8px;color:#64748b;font-size:11px}' +
    '.sign img{height:64px;border:1px solid #e3e8ef;border-radius:8px;background:#fff}</style></head><body>' +
    '<h1>Cierre de barra</h1><div class="sub">' + esc(S.settings.bar) + ' · ' + esc(fechaLarga(t.date)) + ' · ' + hora(t.openedAt) + ' a ' + hora(t.closedAt || now()) + '</div>' +
    '<div class="sub">Turno ' + esc(t.id) + ' · responsable ' + esc(t.by) + (t.receivedFrom ? ' · recibido de ' + esc(t.receivedFrom) : '') + (t.handedTo ? ' · entregado a ' + esc(t.handedTo) : '') + '</div>' +
    '<div class="grid"><div class="box"><div class="k">Ventas</div><div class="v">' + s.nSales + '</div></div>' +
    '<div class="box"><div class="k">Dinero esperado</div><div class="v">' + money(s.total) + '</div></div>' +
    '<div class="box"><div class="k">Anuladas</div><div class="v">' + s.nVoid + '</div></div>' +
    '<div class="box"><div class="k">Cortesías</div><div class="v">' + s.nCortesias + '</div></div></div>' +

    '<h2>Lo que se vendió</h2><table><thead><tr><th>Producto</th><th class="n">Cant.</th><th class="n">Precio</th><th class="n">Total</th></tr></thead><tbody>' +
    (items.length ? items.map(i => '<tr><td>' + esc(i.name) + '</td><td class="n">' + i.qty + '</td><td class="n">' + money(i.total / i.qty) + '</td><td class="n">' + money(i.total) + '</td></tr>').join('') : '<tr><td colspan="4" class="muted">Sin ventas.</td></tr>') +
    '<tr class="tot"><td>Total</td><td class="n">' + items.reduce((a, i) => a + i.qty, 0) + '</td><td></td><td class="n">' + money(s.total) + '</td></tr></tbody></table>' +

    '<h2>Conteo al recibir</h2><table><thead><tr><th>Producto</th><th class="n">Sistema</th><th class="n">Contado</th><th class="n">Diferencia</th></tr></thead><tbody>' + diffRows(countOpen) + '</tbody></table>' +
    '<h2>Conteo al entregar</h2><table><thead><tr><th>Producto</th><th class="n">Sistema</th><th class="n">Contado</th><th class="n">Diferencia</th></tr></thead><tbody>' + diffRows(countClose) + '</tbody></table>' +

    (prodRows ? '<h2>Movimiento del inventario</h2><table><thead><tr><th>Producto</th><th class="n">Inicial</th><th class="n">Ingresa</th><th class="n">Sale</th><th class="n">Cortesía</th><th class="n">Uso bar</th><th class="n">Baja</th><th class="n">Conteo</th><th class="n">Final</th></tr></thead><tbody>' + prodRows + '</tbody></table>' : '') +

    ((t.cortesias || []).length ? '<h2>Cortesías y consumo</h2><table><thead><tr><th>Tipo</th><th>Autoriza</th><th>Qué</th><th>Firma</th></tr></thead><tbody>' +
      t.cortesias.map(c => '<tr class="bloque"><td>' + esc((CORTESIA_TIPOS[c.tipo] || {}).label || c.tipo) + '<div class="sub">' + hora(c.at) + '</div></td><td>' + esc(c.autoriza) + '</td><td>' + esc(c.lines.map(l => l.qty + ' ' + l.name).join(', ')) + '</td><td class="sign">' + (c.firma ? '<img src="' + c.firma + '" alt="firma">' : '—') + '</td></tr>').join('') + '</tbody></table>' : '') +

    '<div class="foot">Generado por Arqueo Bar el ' + esc(fechaLarga(isoDay())) + ' a las ' + hora(now()) + '. ' +
    'Documento de respaldo personal; los números de comanda permiten cruzarlo con el sistema del hotel.</div>' +
    '</body></html>';
}

// Ver el reporte dentro de la app (hoja a pantalla completa)
function viewReport(t) {
  if (!t) { toast('No se encontró el turno'); return; }
  const html = reportHtml(t);
  openSheet({
    full: true, title: 'Cierre ' + fechaCorta(t.date), sub: t.id,
    head: '<button class="icon-btn" id="rEnv" aria-label="Enviar">' + ico('enviar') + '</button>',
    body: '<iframe class="report-frame" id="rf" title="Reporte de cierre"></iframe>',
    onMount(sh) {
      const f = $('#rf', sh);
      f.srcdoc = html;
      $('#rEnv', sh).onclick = () => sharePdf(t);
    },
  });
}

// Crear el PDF y mandarlo por WhatsApp (en el celular) o descargarlo (en el navegador de prueba)
function sharePdf(t) {
  if (!t) return;
  const name = t.pdf || ('Cierre-' + t.id + '.pdf');
  const text = S.settings.bar + ' · cierre del ' + fechaLarga(t.date) + ' · ' + money((t.summary || summarize(t)).total);
  if (!NATIVE) {
    const w = window.open('', '_blank');
    if (w) { w.document.write(reportHtml(t)); w.document.close(); setTimeout(() => w.print(), 400); }
    else toast('El navegador bloqueó la ventana del PDF');
    return;
  }
  toast('Creando el PDF…');
  UI.pdfThen = { name, text };
  Android.makePdf(reportHtml(t), name);
}

window.onPdf = function (name, err) {
  if (err) { toast('No se pudo crear el PDF: ' + err); return; }
  const info = UI.pdfThen || { name, text: '' };
  Android.sharePdf(name, info.text);
};
