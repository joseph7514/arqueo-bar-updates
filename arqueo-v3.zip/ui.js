// Piezas de interfaz reutilizables: hojas, avisos, confirmaciones y la animación de "listo".

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const reduceMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

function haptic(kind = 'tap') { try { if (NATIVE) Android.haptic(kind); else if (navigator.vibrate) navigator.vibrate(kind === 'ok' ? [18, 60, 28] : 8); } catch (e) {} }

let toastTimer = 0;
function toast(msg) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2600);
}
window.toast = toast;

/** Lee un número escrito con coma o punto. */
function num(v) {
  if (typeof v === 'number') return v;
  const s = String(v || '').trim().replace(/\s/g, '').replace(',', '.');
  if (!s) return NaN;
  return Number(s);
}

// ---------- Hojas ----------
const SHEETS = [];

/**
 * Abre una hoja desde abajo. opts: {title, sub, body, foot, full, onMount(el), onClose, dismissible}
 * Devuelve el elemento .sheet; cerrar con closeSheet().
 */
function openSheet(opts) {
  const root = $('#sheets');
  const scrim = document.createElement('div');
  scrim.className = 'scrim';
  const sh = document.createElement('section');
  sh.className = 'sheet' + (opts.full ? ' full' : '');
  sh.setAttribute('role', 'dialog');
  sh.setAttribute('aria-modal', 'true');
  sh.setAttribute('aria-label', opts.title || 'Ventana');
  sh.innerHTML =
    (opts.full ? '' : '<div class="grab" aria-hidden="true"></div>') +
    '<div class="sheet-h">' +
    (opts.full ? '<button class="icon-btn" data-close aria-label="Volver">' + ico('izquierda') + '</button>' : '') +
    '<h2>' + esc(opts.title || '') + (opts.sub ? '<div class="sub">' + esc(opts.sub) + '</div>' : '') + '</h2>' +
    (opts.head || '') +
    (opts.full ? '' : '<button class="icon-btn" data-close aria-label="Cerrar">' + ico('cerrar') + '</button>') +
    '</div>' +
    '<div class="sheet-b">' + (opts.body || '') + '</div>' +
    (opts.foot ? '<div class="sheet-f">' + opts.foot + '</div>' : '');
  root.appendChild(scrim);
  root.appendChild(sh);
  const entry = { sh, scrim, opts };
  SHEETS.push(entry);
  if (opts.dismissible !== false) scrim.addEventListener('click', () => closeSheet());
  $$('[data-close]', sh).forEach(b => b.addEventListener('click', () => closeSheet()));
  if (opts.onMount) opts.onMount(sh);
  return sh;
}

function closeSheet(silent) {
  const entry = SHEETS.pop();
  if (!entry) return false;
  const { sh, scrim, opts } = entry;
  sh.classList.add('out');
  scrim.classList.add('out');
  setTimeout(() => { sh.remove(); scrim.remove(); }, reduceMotion() ? 0 : 190);
  if (!silent && opts.onClose) opts.onClose();
  return true;
}
function closeAllSheets() { while (SHEETS.length) closeSheet(true); }
function topSheet() { return SHEETS.length ? SHEETS[SHEETS.length - 1].sh : null; }

/** Reemplaza el contenido de la hoja de arriba sin animar. */
function setSheetBody(sh, body, foot) {
  $('.sheet-b', sh).innerHTML = body;
  const f = $('.sheet-f', sh);
  if (f && foot != null) f.innerHTML = foot;
}

function confirmSheet({ title, text, ok = 'Confirmar', cancel = 'Cancelar', danger = false }) {
  return new Promise(resolve => {
    let done = false;
    openSheet({
      title,
      body: '<p class="muted" style="margin:0">' + text + '</p>',
      foot: '<button class="btn" data-no>' + esc(cancel) + '</button><button class="btn ' + (danger ? 'danger' : 'primary') + '" data-yes>' + esc(ok) + '</button>',
      onMount(sh) {
        $('[data-no]', sh).onclick = () => closeSheet();
        $('[data-yes]', sh).onclick = () => { done = true; closeSheet(true); resolve(true); };
      },
      onClose() { if (!done) resolve(false); },
    });
  });
}

/** Pide un texto obligatorio (por ejemplo el motivo de una anulación). */
function askText({ title, label, hint = '', ok = 'Guardar', danger = false, value = '', multiline = false, min = 3 }) {
  return new Promise(resolve => {
    let done = false;
    const input = multiline
      ? '<textarea class="input" id="ask" rows="3">' + esc(value) + '</textarea>'
      : '<input class="input" id="ask" value="' + esc(value) + '" autocomplete="off">';
    openSheet({
      title,
      body: '<label class="field"><span>' + esc(label) + '</span>' + input + (hint ? '<div class="hint">' + esc(hint) + '</div>' : '') + '<div class="err" hidden></div></label>',
      foot: '<button class="btn" data-no>Cancelar</button><button class="btn ' + (danger ? 'danger' : 'primary') + '" data-yes>' + esc(ok) + '</button>',
      onMount(sh) {
        const el = $('#ask', sh);
        setTimeout(() => el.focus(), 280);
        $('[data-no]', sh).onclick = () => closeSheet();
        $('[data-yes]', sh).onclick = () => {
          const v = el.value.trim();
          if (v.length < min) {
            el.classList.add('invalid');
            const e = $('.err', sh);
            e.hidden = false;
            e.innerHTML = ico('alerta', 'i-sm') + 'Escribe al menos ' + min + ' letras.';
            el.focus();
            return;
          }
          done = true; closeSheet(true); resolve(v);
        };
      },
      onClose() { if (!done) resolve(null); },
    });
  });
}

// ---------- Celebración al registrar ----------
function celebrate(title, sub) {
  haptic('ok');
  const root = $('#celebra');
  let sparks = '';
  if (!reduceMotion()) {
    for (let i = 0; i < 10; i++) {
      const a = (Math.PI * 2 * i) / 10;
      const d = 70 + (i % 3) * 18;
      sparks += '<i class="spark" style="--dx:' + Math.round(Math.cos(a) * d) + 'px;--dy:' + Math.round(Math.sin(a) * d) + 'px;background:' + (i % 2 ? 'var(--ok)' : 'var(--accent)') + '"></i>';
    }
  }
  root.innerHTML = '<div class="box">' + sparks +
    '<svg class="ring" viewBox="0 0 84 84" aria-hidden="true"><circle cx="42" cy="42" r="36"/><path d="M28 43l9 9 19-20"/></svg>' +
    '<div class="t">' + esc(title) + '</div>' + (sub ? '<div class="s">' + esc(sub) + '</div>' : '') + '</div>';
  const box = $('.box', root);
  setTimeout(() => box.classList.add('out'), 1150);
  setTimeout(() => { if (root.firstChild === box) root.innerHTML = ''; }, 1400);
}

// ---------- Firma en pantalla ----------
function signaturePad(canvas) {
  const ctx = canvas.getContext('2d');
  let drawing = false, has = false, last = null;
  function size() {
    const r = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.round(r.width * dpr);
    canvas.height = Math.round(r.height * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.lineWidth = 2.6; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = '#111827';
  }
  const pos = e => { const r = canvas.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; };
  canvas.addEventListener('pointerdown', e => { drawing = true; last = pos(e); canvas.setPointerCapture(e.pointerId); });
  canvas.addEventListener('pointermove', e => {
    if (!drawing) return;
    const p = pos(e);
    ctx.beginPath(); ctx.moveTo(last.x, last.y); ctx.lineTo(p.x, p.y); ctx.stroke();
    last = p; has = true;
  });
  const end = () => { drawing = false; };
  canvas.addEventListener('pointerup', end);
  canvas.addEventListener('pointercancel', end);
  setTimeout(size, 300);
  return {
    clear() { ctx.clearRect(0, 0, canvas.width, canvas.height); has = false; },
    empty: () => !has,
    data: () => (has ? canvas.toDataURL('image/png') : ''),
  };
}
