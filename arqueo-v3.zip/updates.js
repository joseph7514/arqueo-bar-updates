// Actualizaciones automáticas (firmadas por Joseph), avisos de novedades y Términos y permisos.
//
// La app nativa revisa sola si hay una versión nueva al abrirse y al volver a ella; solo acepta lo que
// trae la firma de Joseph. Aquí solo se muestra el estado y se avisa lo que cambió.

const HAS_OTA = NATIVE && typeof Android.updateStatus === 'function';
let UPD = null;   // hoja de Actualizaciones abierta

function updStatus() {
  try { return JSON.parse(Android.updateStatus()); } catch (e) { return null; }
}
function fechaHora(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d)) return '';
  return d.getDate() + ' ' + MESES[d.getMonth()].slice(0, 3) + ' ' + d.getFullYear() + ', ' + hora(d.getTime());
}
function haceCuanto(ms) {
  if (!ms) return 'todavía no';
  const min = Math.round((Date.now() - ms) / 60000);
  if (min < 1) return 'hace un momento';
  if (min < 60) return 'hace ' + min + ' min';
  const h = Math.round(min / 60);
  if (h < 24) return 'hace ' + h + ' h';
  return fechaCorta(isoDay(ms));
}

function openUpdates() {
  if (!HAS_OTA) {
    openSheet({
      title: 'Actualizaciones', sub: 'Interfaz v' + (window.APP_BUILD || 1),
      body: '<div class="banner info">' + ico('alerta') + '<div>Las actualizaciones automáticas solo funcionan en la app instalada en el celular, no en esta vista de prueba.</div></div>' +
        updExplain(),
    });
    return;
  }
  let st = updStatus() || {};
  let busy = false, pct = 0, msg = '';

  function body() {
    const ready = st.staged && st.stagedInfo;
    return '<div class="card" style="text-align:center">' +
      '<div class="muted small">Versión instalada</div><div class="big-total">v' + st.version + '</div>' +
      '<div class="muted small">' + (st.ota && st.fecha ? 'Publicada por ' + esc(st.autor || 'Joseph') + ' · ' + esc(fechaHora(st.fecha)) : 'La que trae la app ' + esc(Android.version())) + '</div>' +
      '<div style="margin-top:10px"><span class="badge ok">' + ico('escudo', 'i-sm') + 'Automáticas y firmadas</span></div></div>' +
      (st.ota && st.notas ? '<div class="section-t">Lo que trajo esta versión</div><p style="margin:0;white-space:pre-wrap">' + esc(st.notas) + '</p>' : '') +
      '<div class="section-t">Estado</div>' +
      (busy ? '<div class="banner">' + ico('reloj') + '<div class="grow"><b>Buscando…</b><div class="progress" style="margin-top:8px"><i id="upBar" style="width:' + pct + '%"></i></div></div></div>' :
        ready ? '<div class="card"><span class="badge acc">Lista: v' + st.staged + '</span>' +
          (st.stagedInfo.notas ? '<p style="margin:10px 0 0;white-space:pre-wrap">' + esc(st.stagedInfo.notas) + '</p>' : '') +
          '<p class="muted small" style="margin:10px 0 0">Se instala sola la próxima vez que abras la app. Si quieres, instálala ya.</p>' +
          '<button class="btn primary block" id="upNow" style="margin-top:12px">' + ico('bajar') + 'Instalar ahora</button></div>' :
        st.needApk ? '<div class="banner">' + ico('alerta') + '<div>Joseph publicó la versión ' + st.needApk + ', que necesita instalar la app de nuevo. Pídele el archivo de la app.</div></div>' :
        msg ? '<div class="banner info">' + ico('check') + '<div>' + esc(msg) + '</div></div>' :
        st.lastError ? '<div class="banner">' + ico('alerta') + '<div>La última revisión no se pudo hacer: ' + esc(st.lastError) + '. Lo vuelve a intentar sola cuando haya internet.</div></div>' :
        '<div class="banner info">' + ico('check') + '<div>Estás al día.</div></div>') +
      '<p class="muted small">Última revisión: ' + esc(haceCuanto(st.lastCheck)) + '</p>' +
      '<button class="btn block" id="upCheck"' + (busy ? ' disabled' : '') + '>' + ico('buscar') + 'Buscar ahora</button>' +
      updExplain() +
      (st.prev ? '<button class="btn ghost block small" id="upPrev" style="margin-top:16px">Volver a la versión anterior</button>' : '') +
      (st.ota ? '<button class="btn ghost block small" id="upReset">Volver a la versión original de la app</button>' : '');
  }

  const sh = openSheet({
    full: true, title: 'Actualizaciones', sub: 'Mejoras de la app sin reinstalar',
    body: body(),
    onClose() { UPD = null; },
    onMount(shh) {
      function redraw() { st = updStatus() || st; setSheetBody(shh, body()); bind(); }
      UPD = {
        progress(p) { pct = p; const bar = $('#upBar', shh); if (bar) bar.style.width = p + '%'; },
        result(kind, text) { busy = false; msg = kind === 'al-dia' ? text : ''; if (kind === 'error') toast(text); if (kind === 'nueva') haptic('ok'); redraw(); },
      };
      function bind() {
        $('#upCheck', shh).onclick = () => { busy = true; pct = 0; msg = ''; redraw(); Android.checkNow(); };
        if ($('#upNow', shh)) $('#upNow', shh).onclick = () => { toast('Instalando…'); Android.installNow(); };
        if ($('#upPrev', shh)) $('#upPrev', shh).onclick = async () => {
          if (!await confirmSheet({ title: 'Volver a la versión anterior', text: 'Se quita la versión actual y vuelve la anterior. Tus datos no se tocan.', ok: 'Volver', danger: true })) return;
          Android.rollbackUpdate();
        };
        if ($('#upReset', shh)) $('#upReset', shh).onclick = async () => {
          if (!await confirmSheet({ title: 'Volver a la versión original', text: 'Se quitan las actualizaciones y la app vuelve a la que trae instalada. Tus datos no se tocan. Volverá a actualizarse sola cuando Joseph publique una versión nueva.', ok: 'Volver', danger: true })) return;
          Android.resetUpdate();
        };
      }
      bind();
    },
  });
  return sh;
}

function updExplain() {
  return '<div class="section-t">Cómo funciona</div>' +
    accessRow('bajar', 'Se actualiza sola', 'Cuando Joseph publica una mejora, la app la baja en segundo plano y la instala al abrirla, sin interrumpir una venta ni un conteo.') +
    accessRow('escudo', 'Solo lo que firma Joseph', 'Cada versión lleva una firma digital. Si no es de Joseph, la app no la instala.') +
    accessRow('inventario', 'Tus datos no se tocan', 'Cambia la app, no tus ventas, conteos ni turnos. Nada se sube a internet.') +
    accessRow('historial', 'Si algo sale mal, vuelve sola', 'Si una versión nueva no abre bien, la app regresa a la anterior.');
}

window.onUpdateProgress = function (p) { if (UPD) UPD.progress(+p); };
window.onUpdateResult = function (kind, text) {
  if (UPD) UPD.result(kind, text);
};

/** ¿Es buen momento para recargar con la versión nueva? idle = pantalla del PIN; free = sin nada a medias. */
window.updateMoment = function () {
  if (!S || !S.setupDone) return 'busy';
  if (SHEETS.length || (UI.cart && UI.cart.length)) return 'busy';
  if (!UI.unlocked && S.settings.pinHash) return 'idle';
  return 'free';
};

// ---------- Novedades (una vez, después de entrar) ----------
function showNews() {
  const items = [];
  let upd = null;
  if (HAS_OTA) { try { const t = Android.takeUpdateNotice(); upd = t ? JSON.parse(t) : null; } catch (e) { upd = null; } }
  if (upd && upd.tipo === 'nueva') {
    items.push(accessRow('bajar', 'La app se actualizó a la versión ' + upd.version, (upd.notas || 'Mejoras y correcciones.') + ' Publicada por ' + (upd.autor || 'Joseph') + (upd.fecha ? ', ' + fechaHora(upd.fecha) : '') + '.'));
  } else if (upd && upd.texto) {
    items.push(accessRow(upd.tipo === 'error' ? 'alerta' : 'historial', 'Actualización', upd.texto));
  }
  (S.news || []).forEach(n => {
    if (n.tipo !== 'inventario') return;
    const f = n.fecha ? fechaLarga(n.fecha) : 'la última fecha';
    items.push(accessRow('inventario', 'Inventario del ' + f,
      n.used ? 'Se agregaron ' + n.added + ' productos nuevos. Tu stock no se cambió: manda lo que tú contaste.'
        : 'Se cargó el inventario del ' + f + ': ' + n.updated + ' productos con stock nuevo y ' + n.added + ' productos nuevos. Cuéntalo al recibir el bar para confirmarlo.'));
  });
  if (S.news && S.news.length) { S.news = []; saveState(); }
  if (!items.length) return;
  haptic('ok');
  openSheet({
    title: 'Novedades', sub: 'Cambios desde la última vez',
    body: items.join(''),
    foot: '<button class="btn" id="nwGuide">' + ico('guia') + 'Ver la guía</button><button class="btn primary" data-close>Entendido</button>',
    onMount(sh) { $('#nwGuide', sh).onclick = () => { closeSheet(true); openGuide(); }; },
  });
}

/** Después de entrar con el PIN: términos nuevos (una vez) y novedades. */
function afterUnlock() {
  if (S.settings.termsAccepted < TERMS_VERSION) {
    openTerms(true, true).then(ok => {
      if (!ok) return;
      S.settings.termsAccepted = TERMS_VERSION; S.settings.termsAt = Date.now();
      saveState();
      showNews();
    });
    return;
  }
  showNews();
}

// ---------- Foto de un producto desde el celular ----------
function setPhoto(productId) {
  if (!NATIVE) { toast('Las fotos se ponen desde la app en el celular'); return; }
  Android.pickImage(productId);
}
window.onImagePicked = function (productId, dataUrl) {
  const p = PROD[productId];
  if (!p || !dataUrl) return;
  p.img = dataUrl;
  saveState();
  if (PROD_REDRAW) PROD_REDRAW();
  render();
  toast('Foto guardada');
};

// ---------- Términos y permisos ----------
const TERMS_VERSION = 2;
function accessRow(icon, t, s) { return '<div class="feature"><span class="ic">' + ico(icon) + '</span><div><b>' + esc(t) + '</b><div class="muted small">' + esc(s) + '</div></div></div>'; }
function termsHtml(changed) {
  return (changed ? '<div class="banner info" style="margin-bottom:12px">' + ico('alerta') + '<div><b>Cambió una cosa:</b> ahora la app se actualiza sola con las mejoras que publica Joseph. Lo demás sigue igual.</div></div>' : '') +
    '<p class="muted" style="margin-top:0">Arqueo Bar es una herramienta privada para llevar tu inventario. En resumen:</p>' +
    '<div class="section-t" style="margin-top:12px">Qué es</div>' +
    accessRow('escudo', 'Es tuya y privada', 'La usas solo tú, con PIN. No es el sistema del hotel ni se conecta con él.') +
    accessRow('inventario', 'Guarda todo en tu celular', 'Ventas, conteos y turnos quedan solo en este teléfono; no se suben a internet.') +
    accessRow('recibo', 'Es un respaldo personal', 'Sirve como evidencia de lo que vendiste. No reemplaza la factura ni el sistema del hotel.') +
    '<div class="section-t">Qué usa de tu celular</div>' +
    accessRow('botella', 'Vibración', 'Un toque corto al registrar, como confirmación.') +
    accessRow('bajar', 'Archivos', 'Solo cuando guardas un respaldo o compartes el PDF del cierre. Tú eliges el archivo.') +
    accessRow('enviar', 'Otras apps', 'Para enviarte el PDF del cierre por WhatsApp, cuando tú lo pides.') +
    accessRow('buscar', 'Internet, solo para actualizarse', 'La app revisa sola si Joseph publicó una mejora y la instala. Solo acepta versiones con la firma digital de Joseph y nunca envía tus datos. El uso diario funciona sin internet.') +
    '<div class="section-t">Tu responsabilidad</div>' +
    '<p class="small muted">Los datos que registres son tu respaldo. Guarda tus respaldos y tu código de recuperación en un lugar seguro. La app te ayuda a cuadrar el bar; revisa que los conteos y precios sean correctos.</p>';
}

// required=true: hoja con botón Acepto (devuelve Promise<bool>). false: solo lectura desde Más.
// changed=true: ya había aceptado una versión anterior; se resalta lo que cambió.
function openTerms(required, changed) {
  if (!required) {
    openSheet({ full: true, title: 'Términos y permisos', sub: 'Versión ' + TERMS_VERSION, body: termsHtml(false) });
    return Promise.resolve(true);
  }
  return new Promise(resolve => {
    let done = false;
    openSheet({
      full: true, title: 'Términos y permisos', sub: changed ? 'Se actualizaron' : 'Léelo antes de empezar', dismissible: false,
      body: termsHtml(!!changed),
      foot: '<button class="btn primary big block" id="acc">' + ico('check') + 'Entiendo y acepto</button>',
      onMount(sh) {
        $$('.sheet-h [data-close]', sh).forEach(b => b.remove());
        $('#acc', sh).onclick = () => { done = true; closeSheet(true); resolve(true); };
      },
      onClose() { if (!done) resolve(false); },
    });
  });
}
