// Conteo físico al recibir y al entregar, con décimos para botellas abiertas (requisitos R6 y R10).

function countList(kind) {
  // Al abrir: lo que tiene stock o se usa. Al cerrar: además lo que se movió en el turno.
  const movedIds = S.turno ? new Set(S.turno.movs.map(m => m.p)) : new Set();
  return S.products.filter(p => p.active !== false).filter(p => {
    if (kind === 'cerrar' && movedIds.has(p.id)) return true;
    return Math.abs(p.stock) > EPS || (p.conv && ozPer(p));
  });
}

function startCount(kind) {
  const list = countList(kind);
  const draft = {};        // pid -> {counted, same}
  let cat = 'Todos';
  let qOnly = false;       // mostrar solo pendientes

  function cats() { return ['Todos', 'Pendientes'].concat(sortCats(Array.from(new Set(list.map(p => p.cat))), PROD_CATS)); }
  function filtered() {
    let ps = list;
    if (cat === 'Pendientes') ps = ps.filter(p => !(p.id in draft));
    else if (cat !== 'Todos') ps = ps.filter(p => p.cat === cat);
    return ps;
  }
  function doneCount() { return Object.keys(draft).length; }

  function rowHtml(p) {
    const d = draft[p.id];
    const counted = d ? d.counted : null;
    const diff = d ? r4(counted - p.stock) : 0;
    const cls = d ? (Math.abs(diff) > EPS ? 'diff' : 'done') : '';
    let right;
    if (d) {
      right = '<div class="st ' + (Math.abs(diff) > EPS ? 'acc-t' : 'ok-t') + '">' + ico(Math.abs(diff) > EPS ? 'alerta' : 'check', 'i-sm') +
        (Math.abs(diff) > EPS ? (diff < 0 ? 'Faltan ' : 'Sobran ') + qty(Math.abs(diff)) : 'Cuadra') + '</div>';
    } else {
      right = '<button class="same-btn" data-same="' + p.id + '">' + ico('igual', 'i-sm') + 'Igual (' + qty(p.stock) + ')</button>';
    }
    return '<div class="count-row ' + cls + '" data-row="' + p.id + '">' +
      '<div><div class="nm">' + esc(p.name) + '</div><div class="sys">Sistema: ' + stockText(p) + '</div></div>' + right +
      '<div class="full"><button class="btn block" data-count="' + p.id + '">' + (d ? 'Contado: ' + qty(counted) + ' ' + unitShort(p) + ' · tocar para cambiar' : 'Contar') + '</button></div></div>';
  }

  function body() {
    const total = list.length, done = doneCount();
    return '<div style="position:sticky;top:0;background:var(--surface);padding-bottom:8px;z-index:1">' +
      '<div class="row" style="justify-content:space-between"><span class="small"><b>' + done + '</b> de ' + total + ' contados</span>' +
      '<span class="small muted">' + (total - done) + ' por contar</span></div>' +
      '<div class="progress" style="margin:8px 0 12px"><i style="width:' + Math.round(done / total * 100) + '%"></i></div>' +
      '<div class="chips">' + cats().map(c => '<button class="chip" data-cat="' + esc(c) + '" aria-pressed="' + (c === cat) + '">' + esc(c) + (c === 'Pendientes' ? '<span class="cnt"> ' + (total - done) + '</span>' : '') + '</button>').join('') + '</div></div>' +
      '<div id="rows">' + (filtered().length ? filtered().map(rowHtml).join('') : '<div class="empty small">' + (cat === 'Pendientes' ? '¡Todo contado en esta lista!' : 'Nada aquí.') + '</div>') + '</div>';
  }

  const sh = openSheet({
    full: true,
    title: kind === 'abrir' ? 'Contar al recibir' : 'Contar al entregar',
    sub: 'Cuenta lo que ves; lo que no toques queda igual',
    body: body(),
    foot: '<button class="btn" data-close>Después</button><button class="btn primary" id="fin">' + (kind === 'abrir' ? 'Guardar conteo' : 'Revisar y cerrar') + '</button>',
    onMount(shh) {
      $('[data-close]', shh).onclick = () => closeSheet();
      function redraw() {
        const sc = $('.sheet-b', shh).scrollTop;
        setSheetBody(shh, body());
        bind();
        $('.sheet-b', shh).scrollTop = sc;
      }
      function bind() {
        $$('[data-cat]', shh).forEach(b => b.onclick = () => { cat = b.dataset.cat; redraw(); });
        $$('[data-same]', shh).forEach(b => b.onclick = e => {
          e.stopPropagation();
          const p = PROD[b.dataset.same];
          draft[p.id] = { counted: p.stock, same: true };
          haptic();
          redraw();
        });
        $$('[data-count]', shh).forEach(b => b.onclick = () => askTenths(PROD[b.dataset.count], draft[b.dataset.count], val => { draft[b.dataset.count] = { counted: val }; redraw(); }));
      }
      bind();
      $('#fin', shh).onclick = () => {
        if (!doneCount()) { toast('Cuenta al menos un producto'); return; }
        const counts = {};
        Object.keys(draft).forEach(id => counts[id] = draft[id].counted);
        if (kind === 'abrir') {
          saveCount('abrir', counts);
          closeSheet();
          const diffs = Object.keys(counts).filter(id => Math.abs(counts[id] - 0) !== 0 && false).length;
          celebrate('Bar recibido', doneCount() + ' productos contados');
          render();
        } else {
          saveCount('cerrar', counts);
          closeSheet(true);
          reviewAndClose();
        }
      };
    },
  });
  return sh;
}

// Contar una botella: enteras + décimos con un deslizador y un dibujo de botella.
function askTenths(p, cur, onOk) {
  const oz = ozPer(p);
  const canPartial = partial(p);
  let whole = cur ? Math.floor(cur.counted) : Math.max(0, Math.floor(p.stock));
  let tenth = cur ? Math.round((cur.counted - Math.floor(cur.counted)) * 10) : Math.round((p.stock - Math.floor(p.stock)) * 10);
  if (tenth > 9) { whole += 1; tenth = 0; }

  function val() { return r4(whole + (canPartial ? tenth / 10 : 0)); }
  function body() {
    return '<p class="muted small" style="margin-top:0">Sistema: ' + stockText(p) + ' · cuenta lo que ves ahora.</p>' +
      '<div class="field"><span>' + esc(unitName(p, 2).replace(/^./, c => c.toUpperCase())) + ' ' + (canPartial ? 'llenas' : '') + '</span>' +
      '<div class="stepper" style="width:100%;justify-content:space-between"><button id="mw" aria-label="Menos">' + ico('menos1') + '</button><span class="val" id="wv" style="font-size:24px">' + whole + '</span><button id="pw" aria-label="Más">' + ico('mas1') + '</button></div></div>' +
      (canPartial ? '<div class="field"><span>Más una botella abierta (décimos)</span>' +
        '<div class="tenths"><span class="bottle-meter" aria-hidden="true"><i id="meter" style="height:' + (tenth * 10) + '%"></i></span>' +
        '<input type="range" id="tenth" min="0" max="9" step="1" value="' + tenth + '" aria-label="Décimos de botella">' +
        '<output id="tv">' + tenth + '/10</output></div>' +
        (oz ? '<div class="hint" id="ozh">≈ ' + qty((tenth / 10) * oz, 1) + ' oz sueltas</div>' : '') + '</div>' : '') +
      '<div class="card" style="text-align:center"><div class="muted small">Contado</div><div class="big-total" id="tot">' + qty(val()) + ' <span style="font-size:16px">' + esc(unitShort(p)) + '</span></div></div>';
  }
  openSheet({
    title: 'Contar ' + p.name,
    body: body(),
    foot: '<button class="btn" data-close>Cancelar</button><button class="btn primary" id="ok">' + ico('check') + 'Guardar</button>',
    onMount(sh) {
      $('[data-close]', sh).onclick = () => closeSheet();
      function sync() {
        $('#wv', sh).textContent = whole;
        $('#tot', sh).innerHTML = qty(val()) + ' <span style="font-size:16px">' + esc(unitShort(p)) + '</span>';
        if (canPartial) {
          $('#tv', sh).textContent = tenth + '/10';
          $('#meter', sh).style.height = (tenth * 10) + '%';
          if (oz) $('#ozh', sh).textContent = '≈ ' + qty((tenth / 10) * oz, 1) + ' oz sueltas';
        }
      }
      $('#mw', sh).onclick = () => { whole = Math.max(0, whole - 1); haptic(); sync(); };
      $('#pw', sh).onclick = () => { whole++; haptic(); sync(); };
      if (canPartial) $('#tenth', sh).oninput = e => { tenth = +e.target.value; sync(); };
      $('#ok', sh).onclick = () => { onOk(val()); closeSheet(); };
    },
  });
}

// Revisar las diferencias y entregar el bar.
function reviewAndClose() {
  const t = S.turno;
  const lastClose = t.counts.filter(c => c.kind === 'cerrar').pop();
  const diffs = [];
  if (lastClose) Object.keys(lastClose.items).forEach(id => { const [calc, counted] = lastClose.items[id]; if (Math.abs(counted - calc) > EPS) diffs.push({ id, calc, counted }); });
  diffs.sort((a, b) => (a.counted - a.calc) - (b.counted - b.calc));
  const s = summarize(t);
  let handedTo = '';
  openSheet({
    full: true, title: 'Entregar el bar', sub: fechaLarga(t.date) + ' · desde las ' + hora(t.openedAt),
    body: '<div class="card"><div class="kpis" style="margin-top:0"><div class="kpi"><div class="k">Ventas</div><div class="v">' + s.nSales + '</div></div><div class="kpi"><div class="k">Esperado</div><div class="v">' + money(s.total) + '</div></div><div class="kpi"><div class="k">Diferencias</div><div class="v ' + (diffs.length ? 'acc-t' : 'ok-t') + '">' + diffs.length + '</div></div></div></div>' +
      (diffs.length ? '<div class="section-t">Diferencias al entregar</div><p class="muted small">Esto queda como tu respaldo de lo que pasó en el turno. No borra nada.</p>' + diffs.map(d => diffLine(d.id, d.calc, d.counted)).join('')
        : '<div class="banner info" style="margin-top:12px">' + ico('check') + '<div>Todo lo que contaste cuadra con el sistema.</div></div>') +
      '<label class="field" style="margin-top:20px"><span>¿A quién le entregas el bar?</span><input class="input" id="to" autocomplete="off" placeholder="Nombre de la persona"><div class="hint">Opcional. Queda escrito en el cierre.</div></label>',
    foot: '<button class="btn" data-close>Volver</button><button class="btn primary big" id="close">' + ico('candado') + 'Cerrar turno</button>',
    onMount(sh) {
      $('[data-close]', sh).onclick = () => closeSheet();
      $('#close', sh).onclick = async () => {
        handedTo = $('#to', sh).value.trim();
        if (!await confirmSheet({ title: 'Cerrar el turno', text: 'Una vez cerrado no se puede cambiar. Se genera el PDF de cierre para que lo compartas por WhatsApp.', ok: 'Cerrar turno' })) return;
        let closed;
        try { closed = closeTurno(handedTo); } catch (e) { toast(e.message); return; }
        closeAllSheets();
        render();
        celebrate('Turno cerrado', money(closed.summary.total) + ' en ' + closed.summary.nSales + ' ventas');
        setTimeout(() => offerShare(closed), 1300);
      };
    },
  });
}

function offerShare(t) {
  openSheet({
    title: 'Cierre listo', sub: fechaLarga(t.date),
    body: '<div class="empty" style="padding:12px 0 20px">' + ico('pdf', 'i-xl') + '<h2>' + money(t.summary.total) + '</h2><p>' + t.summary.nSales + ' ventas · ' + (t.summary.nCortesias || 0) + ' cortesías</p></div>' +
      '<p class="muted small" style="text-align:center">Envíate el PDF por WhatsApp para tener tu respaldo fuera del celular.</p>',
    foot: '<button class="btn" id="ver">' + ico('pdf') + 'Ver</button><button class="btn primary" id="env">' + ico('enviar') + 'Enviar por WhatsApp</button>',
    onMount(sh) {
      $('#ver', sh).onclick = () => viewReport(t);
      $('#env', sh).onclick = () => sharePdf(t);
    },
  });
}
