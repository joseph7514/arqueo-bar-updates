// Arranque: PIN, bienvenida la primera vez, navegación y bloqueo por inactividad.

const UI = {
  route: 'vender',
  cat: '', q: '', invCat: 'Todos', invQ: '', turnoTab: 'ventas', repTab: 'dia', repDay: '', repPer: 7, repMode: 'carta',
  cart: [], comanda: '', groups: {}, lastFrom: '', pdfThen: null, unlocked: false, lockedAt: 0,
};

const ROUTES = [
  { id: 'vender', label: 'Vender', icon: 'vender', fn: screenVender },
  { id: 'turno', label: 'Turno', icon: 'turno', fn: screenTurno },
  { id: 'inventario', label: 'Inventario', icon: 'inventario', fn: screenInventario },
  { id: 'reportes', label: 'Reportes', icon: 'reportes', fn: screenReportes },
  { id: 'mas', label: 'Más', icon: 'mas', fn: screenMas },
];

function applyTheme() { document.documentElement.setAttribute('data-theme', (S && S.settings.tema) || 'oscuro'); }

function go(route) {
  if (UI.route === route && !SHEETS.length) { $('#view').scrollTo({ top: 0, behavior: reduceMotion() ? 'auto' : 'smooth' }); return; }
  closeAllSheets();
  UI.route = route;
  UI.q = ''; UI.invQ = '';
  render();
}

function render() {
  const r = ROUTES.find(x => x.id === UI.route) || ROUTES[0];
  renderNav();
  r.fn();
  $('#view').classList.remove('has-cart');
  renderCartBar();
}

function renderNav() {
  const hasTurno = !!(S && S.turno);
  $('#nav').innerHTML = ROUTES.map(r => {
    const cur = r.id === UI.route;
    const dot = (r.id === 'turno' && hasTurno) ? '<span class="dot" aria-hidden="true"></span>' : '';
    const pend = r.id === 'mas' && pendCount() ? '<span class="dot" aria-hidden="true"></span>' : '';
    return '<button class="nav-btn" data-go="' + r.id + '" aria-current="' + (cur ? 'page' : 'false') + '">' +
      '<span class="pill">' + ico(r.icon) + '</span><span>' + r.label + '</span>' + dot + pend + '</button>';
  }).join('');
  $$('#nav .nav-btn').forEach(b => b.onclick = () => { haptic(); go(b.dataset.go); });
}

window.appBack = function () {
  if (SHEETS.length) { closeSheet(); return true; }
  if (UI.route !== 'vender') { go('vender'); return true; }
  return false;
};

// ---------- Bloqueo con PIN ----------
let pinBuffer = '';
async function showLock(onOk) {
  const el = $('#lock');
  el.hidden = false;
  pinBuffer = '';
  function dots() { return '<div class="dots" id="dots">' + [0, 1, 2, 3].map(i => '<i class="' + (i < pinBuffer.length ? 'on' : '') + '"></i>').join('') + '</div>'; }
  function draw() {
    el.innerHTML = '<div class="brand">' + ico('botella', 'i-lg') + '</div><h1>Arqueo Bar</h1><p>Escribe tu PIN</p>' + dots() +
      '<div class="keypad">' + [1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => '<button class="key" data-k="' + n + '">' + n + '</button>').join('') +
      '<button class="key ghost" id="forgot">?</button><button class="key" data-k="0">0</button><button class="key ghost" data-k="del" aria-label="Borrar">' + ico('izquierda') + '</button></div>';
    $$('[data-k]', el).forEach(b => b.onclick = () => key(b.dataset.k));
    $('#forgot', el).onclick = recover;
  }
  async function key(k) {
    haptic();
    if (k === 'del') { pinBuffer = pinBuffer.slice(0, -1); $('#dots', el).outerHTML = dots(); return; }
    if (pinBuffer.length >= 4) return;
    pinBuffer += k;
    $('#dots', el).outerHTML = dots();
    if (pinBuffer.length === 4) {
      const ok = await pinHash(pinBuffer) === S.settings.pinHash;
      if (ok) { el.hidden = true; el.innerHTML = ''; onOk(); }
      else {
        const d = $('#dots', el); d.classList.add('shake');
        setTimeout(() => { pinBuffer = ''; draw(); }, 420);
        toast('PIN incorrecto');
      }
    }
  }
  async function recover() {
    const code = await askText({ title: 'Olvidé mi PIN', label: 'Código de recuperación', hint: 'Lo viste al configurar la app (Más › Ajustes).', ok: 'Continuar', min: 8 });
    if (code == null) return;
    if (code.trim().toUpperCase().replace(/-/g, '') !== S.settings.recovery.replace(/-/g, '')) { toast('Ese código no coincide'); return; }
    el.hidden = true;
    showPinSetup(true, () => { el.hidden = true; onOk(); });
  }
  draw();
}

// Crear o cambiar el PIN
function showPinSetup(change, done) {
  let first = '';
  openSheet({
    title: change ? 'Cambiar PIN' : 'Crea tu PIN', sub: '4 números',
    dismissible: !!change,
    body: '<p class="muted" id="msg" style="margin-top:0">Escribe un PIN de 4 números para entrar a la app.</p>' +
      '<input class="input num" id="p1" inputmode="numeric" maxlength="4" style="font-size:28px;letter-spacing:.4em;text-align:center" placeholder="----">' +
      '<input class="input num" id="p2" inputmode="numeric" maxlength="4" style="font-size:28px;letter-spacing:.4em;text-align:center;margin-top:12px" placeholder="repite">',
    foot: (change ? '<button class="btn" data-close>Cancelar</button>' : '') + '<button class="btn primary" id="ok">Guardar PIN</button>',
    onMount(sh) {
      if (change) $('[data-close]', sh).onclick = () => closeSheet();
      else $$('.sheet-h [data-close]', sh).forEach(b => b.remove()); // en la bienvenida, el PIN es obligatorio
      const p1 = $('#p1', sh), p2 = $('#p2', sh);
      setTimeout(() => p1.focus(), 300);
      [p1, p2].forEach(i => i.oninput = () => i.value = i.value.replace(/\D/g, ''));
      $('#ok', sh).onclick = async () => {
        const a = p1.value, b = p2.value;
        if (a.length !== 4) { toast('El PIN debe tener 4 números'); p1.focus(); return; }
        if (a !== b) { toast('Los dos PIN no coinciden'); p2.value = ''; p2.focus(); return; }
        S.settings.pinHash = await pinHash(a);
        if (!S.settings.recovery) S.settings.recovery = newRecovery();
        saveState();
        closeSheet(true);
        if (change) { toast('PIN actualizado'); done && done(); }
        else done && done();
      };
    },
  });
}

// ---------- Bienvenida (primera vez) ----------
function showWelcome() {
  let step = 0;
  const steps = [
    { body: '<div class="brand" style="width:72px;height:72px;margin:8px auto 20px;border-radius:22px;display:grid;place-items:center;background:var(--accent-soft);color:var(--accent-text)">' + ico('botella', 'i-xl') + '</div>' +
      '<h1 style="text-align:center;margin:0 0 6px">Arqueo Bar</h1><p class="muted" style="text-align:center">Tu control privado del bar. Eliges lo que vendes y el inventario se descuenta solo, según tus recetas.</p>' +
      '<div style="margin-top:20px">' +
      feat('vender', 'Vender rápido', 'Tocas el trago, pones la comanda y listo. Se descuenta cada ingrediente.') +
      feat('turno', 'Recibir y entregar', 'Cuentas al empezar y al terminar. Las diferencias quedan como tu respaldo.') +
      feat('escudo', 'Solo tuyo', 'Todo se guarda en este celular, con PIN. No se conecta con el hotel.') + '</div>' },
    { terms: true },
    { body: '<h1 style="margin:0 0 6px">¿Cómo te llamas?</h1><p class="muted">Tu nombre queda como responsable en cada movimiento.</p>' +
      '<label class="field" style="margin-top:20px"><span>Tu nombre</span><input class="input" id="wName" autocomplete="off" placeholder="Ej. Adriana"></label>' +
      '<label class="field"><span>Nombre del bar</span><input class="input" id="wBar" autocomplete="off" value="Bar Monteselva"></label>' },
    { pin: true },
    { recovery: true },
  ];
  const el = $('#lock');
  el.hidden = false;
  function draw() {
    const s = steps[step];
    if (s.terms) {
      el.hidden = true;
      openTerms(true).then(ok => {
        if (!ok) { draw(); return; }
        S.settings.termsAccepted = TERMS_VERSION; S.settings.termsAt = Date.now();
        saveState(); step++; drawOrFinish();
      });
      return;
    }
    if (s.pin) { el.hidden = true; showPinSetup(false, () => { step++; drawOrFinish(); }); return; }
    el.hidden = false;
    if (s.recovery) {
      el.innerHTML = wrap('<h1 style="margin:0 0 6px">Código de recuperación</h1><p class="muted">Si algún día olvidas tu PIN, con este código creas uno nuevo. Guárdalo fuera del celular: una foto o un mensaje a tu WhatsApp.</p>' +
        '<div class="code-box" style="margin-top:20px">' + esc(S.settings.recovery) + '</div>' +
        '<button class="btn block" id="copy" style="margin-top:12px">Copiar código</button>', 'Entendido, empezar', 'start');
      $('#copy', el).onclick = () => { try { navigator.clipboard.writeText(S.settings.recovery); toast('Código copiado'); } catch (e) { toast('Anótalo a mano'); } };
    } else {
      el.innerHTML = wrap(s.body, step === 0 ? 'Empezar' : 'Siguiente', 'next');
    }
    el.querySelectorAll('[data-act]').forEach(b => b.onclick = () => act(b.dataset.act));
  }
  function wrap(inner, btn, act) {
    return '<div class="wizard"><div class="step-dots">' + steps.map((_, i) => '<i class="' + (i <= step ? 'on' : '') + '"></i>').join('') + '</div>' +
      inner + '<button class="btn primary big block" data-act="' + act + '" style="margin-top:24px">' + esc(btn) + '</button></div>';
  }
  function act(a) {
    if (a === 'next' && step === 1) {
      const nm = $('#wName', el).value.trim();
      if (!nm) { toast('Escribe tu nombre'); return; }
      S.settings.responsable = nm;
      S.settings.bar = $('#wBar', el).value.trim() || 'Bar';
      saveState();
    }
    if (a === 'start') { finish(); return; }
    step++; drawOrFinish();
  }
  function drawOrFinish() { if (step >= steps.length) finish(); else draw(); }
  function finish() {
    S.setupDone = true; S.settings.tema = S.settings.tema || 'oscuro';
    saveState();
    el.hidden = true; el.innerHTML = '';
    UI.unlocked = true;
    render();
    // Primera vez: la guía rápida (se puede cerrar y volver a abrir en Más › Guía de uso)
    setTimeout(() => openGuide(), 500);
    S.news = []; saveState();
  }
  draw();
}
function feat(icon, t, s) { return '<div class="feature"><span class="ic">' + ico(icon) + '</span><div><b>' + esc(t) + '</b><div class="muted small">' + esc(s) + '</div></div></div>'; }

// ---------- Inactividad ----------
let lockTimer = 0;
function armLock() {
  clearTimeout(lockTimer);
  const min = S ? S.settings.lockMin : 1;
  if (!min || !UI.unlocked) return;
  lockTimer = setTimeout(() => lockNow(), min * 60000);
}
function lockNow() {
  if (!S.settings.pinHash || !UI.unlocked) return;
  UI.unlocked = false;
  closeAllSheets();
  showLock(() => { UI.unlocked = true; render(); armLock(); });
}
['click', 'touchstart', 'keydown'].forEach(ev => document.addEventListener(ev, armLock, { passive: true }));

window.onNativeResume = function () { armLock(); };
window.onNativePause = function () {
  if (S && S.settings.lockMin === 0 && S.settings.pinHash) UI.unlocked = false;
};

// ---------- Inicio ----------
function boot() {
  loadState();
  applyTheme();
  readyForUpdates();
  if (!S.setupDone) { showWelcome(); return; }
  if (S.settings.pinHash) {
    showLock(() => { UI.unlocked = true; render(); armLock(); afterUnlock(); });
  } else {
    UI.unlocked = true; render(); armLock(); afterUnlock();
  }
}

// Avisa a la app nativa que esta versión de la interfaz abrió bien (si no, vuelve sola a la anterior).
function readyForUpdates() {
  try { if (NATIVE && typeof Android.uiReady === 'function') Android.uiReady(); } catch (e) {}
}
document.addEventListener('DOMContentLoaded', boot);
