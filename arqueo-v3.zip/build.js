// Versión de la interfaz. La app nativa la lee de aquí (UpdateManager.assetBuild).
// herramientas/publicar.py la sube sola al publicar una actualización.
window.APP_BUILD = 3;
