// Ilustraciones por tipo: cada producto/cóctel muestra un dibujo según su clase (botella, copa,
// cerveza, vino, gaseosa…) con el color del licor. Son SVG, livianas, sin internet y se adaptan al tema.
// Si un producto tiene foto real (prod.img o un archivo en PHOTOS), se usa la foto en vez del dibujo.

const LIQ = {
  ambar: '#C27A33', oro: '#E3B55A', dorado: '#E3B55A',
  claro: '#DCE6F2', agua: '#BBD4E8',
  rojo: '#C7362F', rosa: '#E0718A', naranja: '#E08A2B', amarillo: '#E6C33A', verde: '#4E9E57',
  verdeMenta: '#5FB98C', azul: '#2E7CC2', morado: '#7A4FB0', cafe: '#6E4A2E', crema: '#E9D8B0',
  cola: '#4A2A16', tinto: '#7A1E2B', blancoVino: '#E6D79A',
};

function norm2(s) { return (s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase(); }

// ---- Color del líquido según el nombre y la categoría ----
function liqColor(ent) {
  let extra = '';
  if (ent.cat === 'Cócteles' && ent.lines && typeof PROD !== 'undefined') {
    extra = ' ' + ent.lines.map(l => (l.p && PROD[l.p]) ? PROD[l.p].name : (l.n || '')).join(' ');
  }
  const n = norm2(ent.name + ' ' + (ent.raw || '') + extra);
  const has = w => n.includes(w);
  if (has('curacao') || has('laguna azul') || has('blue')) return LIQ.azul;
  if (has('granadina') || has('campari') || has('fresa') || has('sunrise') || has('cereza')) return LIQ.rojo;
  if (has('menta') || has('saltamontes')) return LIQ.verdeMenta;
  if (has('cacao') || has('cafe') || has('expresso') || has('espresso') || has('amaretto') || has('cola') || has('brandy')) return has('cola') ? LIQ.cola : LIQ.cafe;
  if (has('maracuya') || has('naranja') || has('sunrise') || has('aperol') || has('mango')) return has('maracuya') || has('mango') ? LIQ.amarillo : LIQ.naranja;
  if (has('mora')) return LIQ.morado;
  const cat = ent.cat || '';
  if (cat === 'Whisky' || has('whisky') || has('brandy') || has('jager')) return LIQ.ambar;
  if (cat === 'Ron y caña') return has('blanco') || has('silver') || has('bacardi carta blanca') ? LIQ.claro : LIQ.ambar;
  if (cat === 'Tequila') return has('silver') || has('charro') ? LIQ.claro : LIQ.oro;
  if (cat === 'Vodka' || cat === 'Gin') return LIQ.claro;
  if (cat === 'Licores') return LIQ.ambar;
  if (cat === 'Vinos') return has('tinto') ? LIQ.tinto : has('espumante') || has('prosecco') ? LIQ.blancoVino : LIQ.blancoVino;
  if (cat === 'Cervezas') return has('sin alcohol') ? LIQ.dorado : LIQ.ambar;
  if (cat === 'Energizantes') return has('monster') ? LIQ.verde : has('220') ? LIQ.rojo : LIQ.azul;
  if (cat === 'Gaseosas y aguas') return has('coca') || has('cola') ? LIQ.cola : has('sprite') || has('guitig') || has('tonica') ? LIQ.claro : has('fuze') || has('imperial') ? LIQ.ambar : LIQ.agua;
  if (cat === 'Café') return LIQ.cafe;
  if (has('coco') || has('crema de leche') || has('condensada') || has('leche')) return LIQ.crema;
  if (has('pulpa')) return has('mora') ? LIQ.morado : has('coco') ? LIQ.crema : LIQ.rojo;
  return LIQ.ambar;
}

// ---- Familia de vaso para cócteles ----
const GLASS = {
  SUBMARINO: 'cerveza', 'JAGER BOMB': 'shot', 'JÄGER BOMB': 'shot',
  NEGRONI: 'rocas', PADRINO: 'rocas', ALEXANDER: 'coupe',
  MARGARITA: 'margarita', 'APPLE MARTINI': 'martini', 'EXPRESSO MARTINI': 'martini', 'ESPRESSO MARTINI': 'martini',
  'PIÑA COLADA': 'hurricane', 'PINA COLADA': 'hurricane', 'DAIQUIRI FRESA': 'hurricane', 'DAIQUIRI MARACUYÁ': 'hurricane', 'MEDIAS DE SEDA': 'coupe', SALTAMONTES: 'coupe',
  'APEROL SPRITZ': 'vino', 'TINTO DE VERANO': 'vino',
};
function glassFor(it) {
  const key = (it.name || '').toUpperCase();
  if (GLASS[key]) return GLASS[key];
  const k2 = norm2(it.name);
  if (k2.includes('martini')) return 'martini';
  if (k2.includes('margarita')) return 'margarita';
  if (k2.includes('colada') || k2.includes('daiquiri')) return 'hurricane';
  return 'alto'; // highball por defecto (gin tonic, mojito, cuba libre, etc.)
}

// ---- Forma del dibujo según el producto ----
function shapeFor(ent) {
  if (ent.cat === 'Cócteles') return glassFor(ent);
  const n = norm2(ent.name);
  const cat = ent.cat;
  if (cat === 'Cervezas') return n.includes('lata') ? 'lata' : 'botellaCorta';
  if (cat === 'Energizantes') return 'lata';
  if (cat === 'Vinos') return n.includes('espumante') || n.includes('prosecco') ? 'botella' : 'vino';
  if (['Whisky', 'Ron y caña', 'Vodka', 'Tequila', 'Gin', 'Licores'].includes(cat)) return 'botella';
  if (cat === 'Gaseosas y aguas') return n.includes('vidrio') || n.includes('lata') ? 'botellaCorta' : 'botella';
  if (cat === 'Café') return 'taza';
  if (cat === 'Snacks') return 'snack';
  if (cat === 'Desechables') return 'vaso';
  // Insumos
  if (n.includes('pulpa')) return 'pouch';
  if (n.includes('leche') || n.includes('crema') || n.includes('condensada')) return 'tetra';
  if (n.includes('limon') || n.includes('naranja') || n.includes('pina') || n.includes('manzana') || n.includes('cereza') || n.includes('fresa')) return 'fruta';
  if (n.includes('hielo')) return 'hielo';
  return 'frasco';
}

// ---- Dibujos (viewBox 0 0 64 64). g=líquido, s=vidrio ----
function shapeSvg(shape, g) {
  const glass = 'rgba(148,163,184,.9)', glassFill = 'rgba(148,163,184,.14)';
  const L = (d) => `<path d="${d}" fill="${g}"/>`;
  const S = (d, w) => `<path d="${d}" fill="none" stroke="${glass}" stroke-width="${w || 2.4}" stroke-linejoin="round" stroke-linecap="round"/>`;
  const F = (d) => `<path d="${d}" fill="${glassFill}"/>`;
  switch (shape) {
    case 'botella': return F('M27 6h10v7l3 7v36a3 3 0 0 1-3 3H27a3 3 0 0 1-3-3V20l3-7z') + L('M25 30h14v19a2 2 0 0 1-2 2H27a2 2 0 0 1-2-2z') + S('M27 6h10v7l3 7v36a3 3 0 0 1-3 3H27a3 3 0 0 1-3-3V20l3-7z') + S('M27 6h10', 2.4);
    case 'botellaCorta': return F('M26 14h12v6l2 5v27a3 3 0 0 1-3 3H27a3 3 0 0 1-3-3V25l2-5z') + L('M24 32h16v20a2 2 0 0 1-2 2H26a2 2 0 0 1-2-2z') + S('M26 14h12v6l2 5v27a3 3 0 0 1-3 3H27a3 3 0 0 1-3-3V25l2-5z');
    case 'lata': return F('M24 12h16v38a4 4 0 0 1-4 4H28a4 4 0 0 1-4-4z') + L('M24 28h16v22a4 4 0 0 1-4 4H28a4 4 0 0 1-4-4z') + S('M24 14c5 2 11 2 16 0M24 12h16v38a4 4 0 0 1-4 4H28a4 4 0 0 1-4-4z');
    case 'vino': return L('M22 14c0 9 4 13 10 14 6-1 10-5 10-14z') + S('M20 10h24c0 12-5 17-12 18-7-1-12-6-12-18zM32 32v18M24 52h16', 2.4);
    case 'alto': return F('M22 10h20l-2 44a3 3 0 0 1-3 3H27a3 3 0 0 1-3-3z') + L('M23.3 30h17.4l-1.3 24a3 3 0 0 1-3 3H27.6a3 3 0 0 1-3-3z') + S('M22 10h20l-2 44a3 3 0 0 1-3 3H27a3 3 0 0 1-3-3z');
    case 'rocas': return F('M20 20h24l-2 34a3 3 0 0 1-3 3H25a3 3 0 0 1-3-3z') + L('M21.4 38h21.2l-1 16a3 3 0 0 1-3 3H25.4a3 3 0 0 1-3-3z') + S('M20 20h24l-2 34a3 3 0 0 1-3 3H25a3 3 0 0 1-3-3z');
    case 'martini': return L('M24 22h16l-8 9z') + S('M16 16h32L32 34v18M24 58h16M32 52v0', 2.4) + S('M16 16 32 34 48 16', 2.4);
    case 'coupe': return L('M21 22c1 6 5 9 11 9s10-3 11-9z') + S('M18 20h28c0 8-6 13-14 13s-14-5-14-13zM32 33v19M24 54h16', 2.4);
    case 'margarita': return L('M23 24c2 5 5 7 9 7s7-2 9-7z') + S('M14 18c2 4 7 6 7 9 0 4-3 5-3 8 2 3 11 3 14 3s12 0 14-3c0-3-3-4-3-8 0-3 5-5 7-9zM32 36v16M24 54h16', 2.2);
    case 'hurricane': return F('M24 14c-2 10-5 12-3 24s4 12 11 13c7-1 9-1 11-13s-1-14-3-24z') + L('M23 34c0 8 2 11 9 17 7-6 9-9 9-17z') + S('M24 14c-2 10-5 12-3 24s4 12 11 13c7-1 9-1 11-13s-1-14-3-24zM26 14h12', 2.2);
    case 'shot': return F('M23 24h18l-2 28a3 3 0 0 1-3 3H28a3 3 0 0 1-3-3z') + L('M24.2 40h15.6l-.9 12a3 3 0 0 1-3 3H28.1a3 3 0 0 1-3-3z') + S('M23 24h18l-2 28a3 3 0 0 1-3 3H28a3 3 0 0 1-3-3z');
    case 'cerveza': return F('M22 16h18v38a3 3 0 0 1-3 3H25a3 3 0 0 1-3-3z') + L('M22 30h18v24a3 3 0 0 1-3 3H25a3 3 0 0 1-3-3z') + S('M22 16h18v38a3 3 0 0 1-3 3H25a3 3 0 0 1-3-3z') + S('M40 22h4a4 4 0 0 1 0 12h-4', 2.4) + L('M25 11c1-2 4-2 5 0s4 2 5 0 4-1 4 2v3H21v-3c0-3 3-2 4 0z');
    case 'taza': return L('M22 30h20v8a10 10 0 0 1-20 0z') + S('M20 26h24v12a12 12 0 0 1-24 0zM44 30h4a4 4 0 0 1 0 10h-3M18 50h28', 2.4) + S('M27 14c-2 3 2 5 0 8M34 14c-2 3 2 5 0 8', 2);
    case 'snack': return F('M20 12h24v40H20z') + S('M20 12h24v40H20zM20 12l24 40M44 12 20 52', 2) + S('M18 10h28v4H18zM18 50h28v4H18z', 2.2);
    case 'vaso': return F('M22 16h20l-3 38a3 3 0 0 1-3 3H28a3 3 0 0 1-3-3z') + S('M20 16h24l-3 40a3 3 0 0 1-3 3H26a3 3 0 0 1-3-3zM23 28h18', 2.2);
    case 'pouch': return F('M22 16h20v38a4 4 0 0 1-4 4H26a4 4 0 0 1-4-4z') + L('M22 26h20v28a4 4 0 0 1-4 4H26a4 4 0 0 1-4-4z') + S('M22 16h20v38a4 4 0 0 1-4 4H26a4 4 0 0 1-4-4zM26 12h12v4H26z', 2.2);
    case 'tetra': return F('M24 14h16v40H24z') + L('M24 30h16v24H24z') + S('M24 14h16v40H24zM28 14l4-5 4 5', 2.2);
    case 'fruta': return L('M32 22a15 16 0 1 0 .1 0z') + S('M32 22a15 16 0 1 0 .1 0zM32 22c0-5 3-8 8-9', 2.4);
    case 'hielo': return F('M18 28 30 20l10 6-2 14-12 6-10-8z') + S('M18 28 30 20l10 6-2 14-12 6-10-8zM30 20v9l8 3M30 29l-12 3', 2.2);
    default: return F('M24 16h16v34a4 4 0 0 1-4 4H28a4 4 0 0 1-4-4z') + L('M24 30h16v20a4 4 0 0 1-4 4H28a4 4 0 0 1-4-4z') + S('M24 16h16v34a4 4 0 0 1-4 4H28a4 4 0 0 1-4-4zM26 12h12v4H26z', 2.2);
  }
}

function illusSvg(ent, px) {
  const g = liqColor(ent);
  const shape = shapeFor(ent);
  const p = px || 56;
  return '<svg class="illus" viewBox="0 0 64 64" width="' + p + '" height="' + p + '" aria-hidden="true">' + shapeSvg(shape, g) + '</svg>';
}

// Lista de slugs que tienen foto real en el bundle (la escribe el empaquetador). Vacío = solo dibujos.
const PHOTO_SET = new Set((window.PHOTOS || []));

/** Devuelve el HTML de la miniatura: foto del celular, foto del bundle, o la ilustración. */
function thumb(ent, px) {
  const p = px || 56;
  if (ent.img) return '<span class="thumb" style="width:' + p + 'px;height:' + p + 'px"><img src="' + esc(ent.img) + '" alt="" loading="lazy"></span>';
  if (ent.slug && PHOTO_SET.has(ent.slug)) {
    const fb = illusSvg(ent, p).replace(/"/g, '&quot;');
    return '<span class="thumb" style="width:' + p + 'px;height:' + p + 'px"><img src="img/' + ent.slug + '.webp" alt="" loading="lazy" onerror="this.outerHTML=this.getAttribute(\'data-fb\')" data-fb="' + fb + '"></span>';
  }
  return '<span class="thumb" style="width:' + p + 'px;height:' + p + 'px">' + illusSvg(ent, p) + '</span>';
}
