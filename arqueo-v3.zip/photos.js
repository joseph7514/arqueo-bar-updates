// Fotos reales incluidas en el bundle, por slug (lo genera publicar.py).
window.PHOTOS = [];
