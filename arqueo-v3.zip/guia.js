// Guía de uso dentro de la app: tarjetas que se deslizan, agrupadas por tema (sin scroll largo).

const GUIA = [
  {
    tema: 'La idea', cards: [
      {
        icon: 'botella', t: 'Cómo funciona',
        intro: 'Tu día en el bar tiene tres momentos. La app lleva la cuenta por ti.',
        steps: [
          ['recibir', '<b>Recibes el bar</b> y cuentas lo que te entregan.'],
          ['vender', '<b>Vendes.</b> Cada venta descuenta sola sus ingredientes, según la receta.'],
          ['entregar', '<b>Entregas el bar:</b> cuentas otra vez y sale el PDF del cierre.'],
        ],
        tip: 'Lo que no cuadra queda anotado como diferencia, con hora y responsable. Ese es tu respaldo.',
      },
      {
        icon: 'mas', t: 'Las pestañas de abajo',
        steps: [
          ['vender', '<b>Vender:</b> la carta para registrar lo que sale.'],
          ['turno', '<b>Turno:</b> recibir, ingresos, cortesías, roturas y entregar. Un punto aquí = turno abierto.'],
          ['inventario', '<b>Inventario:</b> cuánto hay de cada producto.'],
          ['reportes', '<b>Reportes:</b> ventas por día, por producto y turnos cerrados.'],
          ['mas', '<b>Más:</b> carta y precios, respaldo, ajustes y esta guía.'],
        ],
      },
    ],
  },
  {
    tema: 'Recibir', cards: [
      {
        icon: 'recibir', t: 'Recibir el bar',
        steps: [
          ['turno', 'Ve a <b>Turno › Recibir el bar</b>.'],
          ['usuario', 'Escribe quién te entrega. El primer día pon <b>Inventario inicial</b>.'],
          ['igual', 'Si coincide, toca <b>Igual</b>. Si no, toca <b>Contar</b> y pon lo que ves.'],
          ['check', 'Toca <b>Guardar conteo</b>.'],
        ],
        tip: 'Lo que no cuentes queda como está. Puedes tocar Después y seguir con Contar ahora.',
      },
      {
        icon: 'botella', t: 'Botellas abiertas',
        intro: 'En Contar pones las botellas enteras y, con la barra, cuánto queda en la abierta.',
        steps: [
          ['mas1', 'Botellas enteras con <b>+</b> y <b>−</b>.'],
          ['botella', 'Desliza los <b>décimos</b>: 5/10 es media botella. La app calcula las onzas.'],
        ],
        tip: 'Con el limón, la pulpa y el azúcar pasa igual: se cuentan por partes.',
      },
    ],
  },
  {
    tema: 'Vender', cards: [
      {
        icon: 'vender', t: 'Registrar una venta',
        steps: [
          ['buscar', 'En <b>Vender</b> toca el trago. Usa el buscador o las categorías.'],
          ['botella', 'Si tiene presentaciones (trago, botella o copa), elige una.'],
          ['recibo', 'Toca la barra de abajo para ver la comanda.'],
          ['check', 'Escribe el <b>número de comanda</b> y regístrala.'],
        ],
        tip: 'Si el sistema dice que no alcanza, la venta se registra igual y el conteo lo corrige.',
      },
      {
        icon: 'anular', t: '2x1 y anulaciones',
        steps: [
          ['cortesia', '<b>2x1:</b> en la comanda toca 2x1. Salen dos, cobras uno, y se descuentan los dos.'],
          ['anular', '<b>Anular:</b> Turno › Ventas › toca la comanda › Anular, y escribe el motivo.'],
        ],
        tip: 'Nada se borra. Una anulación devuelve lo descontado y queda registrada.',
      },
    ],
  },
  {
    tema: 'Durante el turno', cards: [
      {
        icon: 'turno', t: 'Lo que entra y lo que sale sin venta',
        steps: [
          ['ingreso', '<b>Ingreso:</b> llegó producto. Pon el proveedor, si firmaste y las cantidades.'],
          ['cortesia', '<b>Cortesía:</b> de paquete (firma quien autoriza), de feriado o consumo del personal.'],
          ['rotura', '<b>Rotura o merma:</b> el producto y el motivo (rotura, merma, vencido, derrame).'],
        ],
        tip: 'Todo está en la pestaña Turno mientras el turno esté abierto.',
      },
    ],
  },
  {
    tema: 'Entregar', cards: [
      {
        icon: 'entregar', t: 'Entregar el bar',
        steps: [
          ['turno', 'Ve a <b>Turno › Entregar el bar</b>.'],
          ['igual', 'Cuenta lo que entregas. La lista incluye todo lo que se movió en el turno.'],
          ['usuario', 'Revisa las diferencias y escribe a quién entregas.'],
          ['candado', '<b>Cerrar turno:</b> después ya no se puede cambiar.'],
          ['enviar', 'Envíate el <b>PDF</b> por WhatsApp para tenerlo fuera del celular.'],
        ],
      },
    ],
  },
  {
    tema: 'Inventario y reportes', cards: [
      {
        icon: 'inventario', t: 'Inventario',
        steps: [
          ['buscar', 'Busca o filtra por categoría.'],
          ['botella', 'Toca un producto para ver su conversión, en qué tragos se usa y sus movimientos.'],
          ['subir', 'También puedes ponerle una <b>foto</b> desde el celular.'],
          ['nuevo', 'Si llega algo que no existe, créalo en <b>Más › Nuevo producto</b>.'],
        ],
      },
      {
        icon: 'reportes', t: 'Reportes y Excel',
        steps: [
          ['reportes', '<b>Reportes:</b> lo vendido por día, por producto y cada turno cerrado.'],
          ['tabla', '<b>Más › Exportar a Excel:</b> columnas como tu hoja: ingresa, sale, cortesía y uso en el bar.'],
          ['pendiente', '<b>Más › Datos por confirmar:</b> medidas y precios que faltan revisar.'],
        ],
      },
    ],
  },
  {
    tema: 'Tu seguridad', cards: [
      {
        icon: 'escudo', t: 'PIN y respaldo',
        steps: [
          ['candado', 'La app se bloquea sola con tu <b>PIN</b>. El tiempo se cambia en Ajustes.'],
          ['usuario', '¿Olvidaste el PIN? Toca <b>?</b> y usa tu <b>código de recuperación</b>.'],
          ['escudo', '<b>Más › Respaldo</b> guarda todo en un archivo. Hazlo cada semana.'],
        ],
        warn: 'No desinstales la app: se borran tus datos. Para una versión nueva, se instala encima.',
      },
    ],
  },
  {
    tema: 'Actualizaciones', cards: [
      {
        icon: 'bajar', t: 'La app se actualiza sola',
        steps: [
          ['bajar', 'Cuando Joseph publica una mejora, la app la baja sola y la instala al abrirla.'],
          ['escudo', 'Solo instala versiones con la <b>firma digital de Joseph</b>.'],
          ['inventario', 'Tus ventas, conteos y turnos <b>no se tocan</b>.'],
          ['alerta', 'Al entrar verás un aviso con lo que cambió.'],
        ],
        tip: 'En Más › Actualizaciones ves la versión que tienes y puedes buscar una nueva.',
      },
    ],
  },
];

function openGuide(startTema) {
  const flat = [];
  GUIA.forEach((g, gi) => g.cards.forEach((c, ci) => flat.push({ gi, ci, c })));
  let idx = Math.max(0, startTema ? flat.findIndex(f => GUIA[f.gi].tema === startTema) : 0);

  function cardHtml(c, i) {
    return '<article class="g-card" data-i="' + i + '" aria-roledescription="tarjeta" aria-label="' + esc(c.t) + '">' +
      '<div class="g-hero">' + ico(c.icon, 'i-xl') + '</div>' +
      '<h3>' + esc(c.t) + '</h3>' +
      (c.intro ? '<p class="muted" style="margin:0 0 6px">' + esc(c.intro) + '</p>' : '') +
      '<ol class="g-steps">' + c.steps.map((s, n) => '<li><span class="n">' + (n + 1) + '</span><span class="g-ic">' + ico(s[0], 'i-sm') + '</span><span>' + s[1] + '</span></li>').join('') + '</ol>' +
      (c.tip ? '<div class="banner info">' + ico('check') + '<div>' + esc(c.tip) + '</div></div>' : '') +
      (c.warn ? '<div class="banner">' + ico('alerta') + '<div><b>' + esc(c.warn) + '</b></div></div>' : '') +
      '</article>';
  }
  function chips() {
    const cur = flat[idx].gi;
    return GUIA.map((g, gi) => '<button class="chip" data-tema="' + gi + '" aria-pressed="' + (gi === cur) + '">' + esc(g.tema) + '</button>').join('');
  }
  function dots() { return flat.map((_, i) => '<i class="' + (i === idx ? 'on' : '') + '"></i>').join(''); }

  openSheet({
    full: true, title: 'Guía de uso', sub: 'Desliza para pasar de tarjeta',
    body: '<div class="chips g-chips" id="gChips">' + chips() + '</div>' +
      '<div class="guide" id="gTrack">' + flat.map((f, i) => cardHtml(f.c, i)).join('') + '</div>',
    foot: '<button class="btn" id="gPrev">' + ico('izquierda') + 'Anterior</button>' +
      '<div class="g-dots" id="gDots" aria-hidden="true">' + dots() + '</div>' +
      '<button class="btn primary" id="gNext">Siguiente' + ico('derecha') + '</button>',
    onMount(sh) {
      const track = $('#gTrack', sh);
      let scrollT = 0;
      function sync(scrollChips) {
        $$('.g-card', sh).forEach((c, i) => c.classList.toggle('cur', i === idx));
        $('#gDots', sh).innerHTML = dots();
        $('#gChips', sh).innerHTML = chips();
        bindChips();
        if (scrollChips) {
          // Solo se mueve la fila de temas (scrollIntoView cortaría el deslizamiento de la tarjeta)
          const row = $('#gChips', sh), on = $('#gChips [aria-pressed="true"]', sh);
          if (on) row.scrollTo({ left: on.offsetLeft - (row.clientWidth - on.offsetWidth) / 2, behavior: reduceMotion() ? 'auto' : 'smooth' });
        }
        $('#gPrev', sh).disabled = idx === 0;
        $('#gNext', sh).innerHTML = idx === flat.length - 1 ? ico('check') + 'Listo' : 'Siguiente' + ico('derecha');
      }
      // Mientras se desliza por un botón, los eventos de scroll intermedios no cambian la tarjeta actual
      let targetUntil = 0;
      function goTo(i) {
        idx = Math.max(0, Math.min(flat.length - 1, i));
        targetUntil = Date.now() + 900;
        track.scrollTo({ left: idx * track.clientWidth, behavior: reduceMotion() ? 'auto' : 'smooth' });
        sync(true);
      }
      function bindChips() {
        $$('[data-tema]', sh).forEach(b => b.onclick = () => { haptic(); goTo(flat.findIndex(f => f.gi === +b.dataset.tema)); });
      }
      function settle() {
        const w = Math.max(1, track.clientWidth);
        if (Date.now() < targetUntil && Math.abs(track.scrollLeft - idx * w) > 2) {
          scrollT = setTimeout(settle, targetUntil - Date.now() + 20);
          return;
        }
        targetUntil = 0;
        const i = Math.round(track.scrollLeft / w);
        if (i !== idx) { idx = i; sync(true); }
      }
      track.addEventListener('scroll', () => { clearTimeout(scrollT); scrollT = setTimeout(settle, 120); }, { passive: true });
      // Si ella desliza con el dedo, manda el dedo
      track.addEventListener('pointerdown', () => { targetUntil = 0; }, { passive: true });
      track.addEventListener('touchstart', () => { targetUntil = 0; }, { passive: true });
      $('#gPrev', sh).onclick = () => { haptic(); goTo(idx - 1); };
      $('#gNext', sh).onclick = () => {
        haptic();
        if (idx === flat.length - 1) { closeSheet(); celebrate('Guía completa', 'Ya sabes usar Arqueo Bar'); return; }
        goTo(idx + 1);
      };
      sync(false);
      if (idx) setTimeout(() => { track.scrollLeft = idx * track.clientWidth; }, 0);
    },
  });
}
