// Las cinco pantallas principales y sus hojas.

const CAT_ORDER = ['Cócteles', 'Cervezas', 'Gaseosas y aguas', 'Energizantes', 'Whisky', 'Ron y caña', 'Vodka', 'Tequila', 'Gin', 'Licores', 'Vinos', 'Snacks', 'Café'];
let PROD_REDRAW = null;   // redibuja el detalle de producto abierto tras poner una foto
const PROD_CATS = ['Whisky', 'Ron y caña', 'Vodka', 'Tequila', 'Gin', 'Licores', 'Vinos', 'Cervezas', 'Gaseosas y aguas', 'Energizantes', 'Snacks', 'Insumos', 'Desechables'];

function setTop(title, sub, right) {
  $('#top').innerHTML = '<div class="grow"><h1>' + esc(title) + '</h1>' + (sub ? '<div class="sub">' + sub + '</div>' : '') + '</div>' + (right || '');
}
function sortCats(list, order) { return list.sort((a, b) => (order.indexOf(a) + 1 || 99) - (order.indexOf(b) + 1 || 99)); }

// =====================================================================
// VENDER
// =====================================================================
function frequentItems() {
  const tally = {};
  S.closed.slice(-12).forEach(c => Object.keys(c.byItem || {}).forEach(id => tally[id] = (tally[id] || 0) + c.byItem[id].qty));
  if (S.turno) S.turno.sales.forEach(s => !s.void && s.lines.forEach(l => tally[l.item] = (tally[l.item] || 0) + l.qty));
  return Object.keys(tally).filter(id => ITEM[id] && ITEM[id].active !== false).sort((a, b) => tally[b] - tally[a]).slice(0, 12);
}

function sellGroups() {
  const q = norm(UI.q);
  let items = S.items.filter(i => i.active !== false);
  if (q) items = items.filter(i => norm(i.name + ' ' + (i.variant || '') + ' ' + i.cat).includes(q));
  else if (UI.cat === 'Frecuentes') { const f = frequentItems(); items = f.map(id => ITEM[id]); }
  else items = items.filter(i => i.cat === UI.cat);
  const groups = [], seen = {};
  items.forEach(it => {
    const key = it.group ? 'g:' + it.group : it.id;
    if (!seen[key]) { seen[key] = { key, name: it.name, items: [] }; groups.push(seen[key]); }
    seen[key].items.push(it);
  });
  return groups;
}
function cartQty(g) { return UI.cart.filter(l => g.items.some(i => i.id === l.item)).reduce((a, l) => a + l.qty, 0); }

function tileHtml(g) {
  const qn = cartQty(g);
  const prices = g.items.map(i => i.price);
  const min = Math.min.apply(null, prices);
  const price = g.items.length > 1 ? 'desde ' + money(min) : money(min);
  const vars = g.items.length > 1 ? g.items.map(i => i.variant).join(' · ') : (g.items[0].cat === 'Cócteles' ? '' : '');
  const low = g.items.every(itemLow);
  return '<button class="tile' + (qn ? ' in-cart' : '') + (low ? ' low' : '') + '" data-key="' + esc(g.key) + '" aria-label="' + esc(g.name + ', ' + price + (qn ? ', ' + qn + ' en la comanda' : '')) + '">' +
    thumb(g.items[0], 44) +
    '<span class="n">' + esc(g.name) + '</span>' +
    '<span><span class="p">' + price + '</span>' + (vars ? '<span class="vars"> · ' + esc(vars) + '</span>' : '') + '</span>' +
    (qn ? '<span class="q">' + qn + '</span>' : '') + '</button>';
}

function screenVender() {
  const t = S.turno;
  setTop('Vender', t ? 'Turno abierto desde las ' + hora(t.openedAt) : 'Sin turno abierto',
    '<button class="icon-btn" id="goPend" aria-label="Datos por confirmar">' + ico('pendiente') + '</button>');
  $('#goPend').onclick = () => openPendientes();
  const v = $('#view');
  if (!t) {
    v.innerHTML = '<div class="empty">' + ico('recibir', 'i-xl') + '<h2>Primero recibe el bar</h2>' +
      '<p>Antes de vender, cuenta lo que te entregan. Así tus ventas y tu conteo quedan en el mismo turno.</p>' +
      '<button class="btn primary big block" id="recv">' + ico('recibir') + 'Recibir el bar</button></div>';
    $('#recv').onclick = () => startReceive();
    return;
  }
  if (!UI.cat) UI.cat = frequentItems().length >= 4 ? 'Frecuentes' : 'Cócteles';
  const cats = sortCats(Array.from(new Set(S.items.filter(i => i.active !== false).map(i => i.cat))), CAT_ORDER);
  if (frequentItems().length >= 4) cats.unshift('Frecuentes');
  const sales = t.sales.filter(s => !s.void);
  v.innerHTML =
    '<div class="sell-head">' +
    (S.settings.pricesOk ? '' : '<div class="banner">' + ico('alerta') + '<div class="grow">Los precios son <b>de prueba</b>. Cárgalos desde la carta del hotel en <b>Más › Carta y precios</b>.</div></div>') +
    '<div class="turn-strip"><span class="live" aria-hidden="true"></span><div class="grow small"><b>' + sales.length + ' ventas</b> · esperado <b class="num">' + money(sales.reduce((a, s) => a + s.total, 0)) + '</b></div>' +
    '<button class="btn ghost small" id="lastSales">Ver ventas</button></div>' +
    '<div class="search">' + ico('buscar') + '<input class="input" id="q" type="search" placeholder="Buscar en la carta" value="' + esc(UI.q) + '" aria-label="Buscar en la carta" autocomplete="off">' +
    (UI.q ? '<button class="icon-btn clear" id="qx" aria-label="Borrar búsqueda">' + ico('cerrar', 'i-sm') + '</button>' : '') + '</div>' +
    '<div class="chips" role="toolbar" aria-label="Categorías"' + (UI.q ? ' hidden' : '') + '>' +
    cats.map(c => '<button class="chip" data-cat="' + esc(c) + '" aria-pressed="' + (c === UI.cat) + '">' + esc(c) + '</button>').join('') + '</div>' +
    '</div><div class="tiles" id="tiles"></div>';
  renderTiles();
  const qi = $('#q');
  qi.oninput = () => { UI.q = qi.value; renderTiles(); $('.chips', v).hidden = !!UI.q; };
  qi.onkeydown = e => { if (e.key === 'Enter') qi.blur(); };
  if ($('#qx')) $('#qx').onclick = () => { UI.q = ''; render(); };
  $$('.chip', v).forEach(c => c.onclick = () => {
    UI.cat = c.dataset.cat;
    $$('.chip', v).forEach(x => x.setAttribute('aria-pressed', x === c));
    renderTiles();
    c.scrollIntoView({ inline: 'nearest', block: 'nearest', behavior: reduceMotion() ? 'auto' : 'smooth' });
  });
  $('#lastSales').onclick = () => { UI.turnoTab = 'ventas'; go('turno'); };
}

function renderTiles() {
  const el = $('#tiles'); if (!el) return;
  const groups = sellGroups();
  el.innerHTML = groups.length ? groups.map(tileHtml).join('') :
    '<div class="empty" style="grid-column:1/-1">' + ico('buscar', 'i-xl') + '<h2>Sin resultados</h2><p>Prueba con otra palabra o revisa la carta en Más.</p></div>';
  UI.groups = {};
  groups.forEach(g => UI.groups[g.key] = g);
  $$('.tile', el).forEach(b => b.onclick = () => tapTile(UI.groups[b.dataset.key], b));
}

function tapTile(g, btn) {
  if (g.items.length === 1) { addToCart(g.items[0].id); bumpTile(btn, g); return; }
  openSheet({
    title: g.name, sub: 'Elige cómo lo vendes',
    body: '<div class="choices">' + g.items.map(i => '<button class="choice" data-item="' + i.id + '"><span>' + esc(i.variant) +
      '<span class="muted small" style="display:block;font-weight:500">' + esc((i.lines || []).map(lineText).join(', ')) + '</span></span><span class="p">' + money(i.price) + '</span></button>').join('') + '</div>',
    onMount(sh) {
      $$('.choice', sh).forEach(b => b.onclick = () => { addToCart(b.dataset.item); closeSheet(); bumpTile(btn, g); });
    },
  });
}
function bumpTile(btn, g) {
  const fresh = document.createElement('div');
  fresh.innerHTML = tileHtml(g);
  const nb = fresh.firstChild;
  nb.onclick = () => tapTile(g, nb);
  if (!reduceMotion()) nb.classList.add('bump');
  btn.replaceWith(nb);
}

function addToCart(itemId) {
  const l = UI.cart.find(x => x.item === itemId && !x.promo);
  if (l) l.qty++; else UI.cart.push({ item: itemId, qty: 1, promo: null });
  haptic();
  renderCartBar();
}
function cartTotal() { return r2(UI.cart.reduce((a, l) => a + l.qty * ITEM[l.item].price, 0)); }

function renderCartBar() {
  const bar = $('#cartbar');
  const show = UI.route === 'vender' && UI.cart.length && S.turno && !SHEETS.length;
  $('#view').classList.toggle('has-cart', !!(UI.route === 'vender' && UI.cart.length));
  if (!show) { bar.hidden = true; return; }
  const n = UI.cart.reduce((a, l) => a + l.qty, 0);
  bar.hidden = false;
  bar.innerHTML = '<div class="grow"><div class="ct">' + n + (n === 1 ? ' producto' : ' productos') + '</div><div class="num" style="font-size:20px;font-weight:800">' + money(cartTotal()) + '</div></div>' +
    '<button class="btn primary" id="cobrar">' + ico('recibo') + 'Registrar</button>';
  $('#cobrar').onclick = () => openCart();
}

function openCart() {
  let comanda = UI.comanda || '';
  function body() {
    const missing = [], negative = [];
    UI.cart.forEach(l => {
      const it = ITEM[l.item];
      missingConv(it).forEach(n => missing.push(n));
      explode(it, l.promo === '2x1' ? l.qty * 2 : l.qty).forEach(x => { if (PROD[x.p].stock - x.q < -EPS) negative.push(PROD[x.p].name); });
    });
    return '<label class="field"><span>Número de comanda</span>' +
      '<input class="input num" id="comanda" inputmode="numeric" autocomplete="off" placeholder="Ej. 1532" value="' + esc(comanda) + '">' +
      '<div class="err" id="comErr" hidden>' + ico('alerta', 'i-sm') + 'Escribe el número de la comanda o ticket.</div></label>' +
      UI.cart.map((l, i) => {
        const it = ITEM[l.item];
        const total = l.qty * it.price;
        return '<div class="cart-line"><div class="grow"><div style="font-weight:650">' + esc(itemLabel(it)) + '</div>' +
          '<div class="muted small num">' + money(it.price) + (l.promo ? ' · 2x1: salen ' + l.qty * 2 + ', cobras ' + l.qty : '') + '</div></div>' +
          '<div class="num" style="font-weight:800">' + money(total) + '</div>' +
          '<div class="ctrl" style="grid-column:1/-1;justify-content:space-between">' +
          '<button class="toggle-chip" data-promo="' + i + '" aria-pressed="' + (l.promo === '2x1') + '">2x1</button>' +
          '<div class="stepper"><button data-dec="' + i + '" aria-label="Quitar uno">' + ico(l.qty === 1 ? 'basura' : 'menos1', 'i-sm') + '</button><span class="val">' + l.qty + '</span>' +
          '<button data-inc="' + i + '" aria-label="Agregar uno">' + ico('mas1', 'i-sm') + '</button></div></div></div>';
      }).join('') +
      (negative.length ? '<div class="banner info" style="margin-top:12px">' + ico('alerta') + '<div>Según el sistema no alcanza: ' + esc(Array.from(new Set(negative)).join(', ')) + '. Se registra igual y el conteo lo corrige.</div></div>' : '') +
      (missing.length ? '<div class="banner" style="margin-top:12px">' + ico('alerta') + '<div>Sin conversión, no se descuenta: ' + esc(Array.from(new Set(missing)).join(', ')) + '.</div></div>' : '') +
      '<div class="total-row"><span class="muted">Total a cobrar</span><b>' + money(cartTotal()) + '</b></div>';
  }
  const foot = '<button class="btn" id="vaciar">Vaciar</button><button class="btn primary big" id="registrar">' + ico('check') + 'Registrar venta</button>';
  openSheet({
    title: 'Comanda', body: body(), foot,
    onClose() { UI.comanda = comanda; renderCartBar(); render(); },
    onMount(sh) {
      $('#cartbar').hidden = true;
      function bind() {
        const ci = $('#comanda', sh);
        ci.oninput = () => { comanda = ci.value.replace(/[^\w-]/g, ''); ci.classList.remove('invalid'); $('#comErr', sh).hidden = true; };
        $$('[data-inc]', sh).forEach(b => b.onclick = () => { UI.cart[+b.dataset.inc].qty++; haptic(); refresh(); });
        $$('[data-dec]', sh).forEach(b => b.onclick = () => {
          const l = UI.cart[+b.dataset.dec];
          l.qty--; haptic();
          if (l.qty <= 0) UI.cart.splice(+b.dataset.dec, 1);
          if (!UI.cart.length) { closeSheet(); return; }
          refresh();
        });
        $$('[data-promo]', sh).forEach(b => b.onclick = () => { const l = UI.cart[+b.dataset.promo]; l.promo = l.promo ? null : '2x1'; haptic(); refresh(); });
      }
      function refresh() { const st = $('.sheet-b', sh).scrollTop; setSheetBody(sh, body()); bind(); $('.sheet-b', sh).scrollTop = st; }
      bind();
      if (!comanda) setTimeout(() => $('#comanda', sh).focus(), 300);
      $('#vaciar', sh).onclick = async () => {
        if (await confirmSheet({ title: 'Vaciar la comanda', text: 'Se quitan todos los productos sin registrar nada.', ok: 'Vaciar', danger: true })) {
          UI.cart = []; comanda = ''; closeSheet();
        }
      };
      $('#registrar', sh).onclick = () => {
        if (!comanda.trim()) {
          const ci = $('#comanda', sh);
          ci.classList.add('invalid'); $('#comErr', sh).hidden = false; ci.focus();
          return;
        }
        const dup = S.turno.sales.some(s => !s.void && s.comanda === comanda.trim());
        const sale = registerSale(comanda, UI.cart);
        UI.cart = []; comanda = ''; UI.comanda = '';
        closeSheet();
        celebrate('Venta registrada', 'Comanda ' + sale.comanda + ' · ' + money(sale.total));
        if (dup) setTimeout(() => toast('Ojo: la comanda ' + sale.comanda + ' ya tenía otra venta en este turno'), 1500);
      };
    },
  });
}

// =====================================================================
// TURNO
// =====================================================================
function startReceive() {
  if (S.turno) { startCount('abrir'); return; }
  openSheet({
    title: 'Recibir el bar',
    body: '<p class="muted" style="margin-top:0">Abre tu turno y cuenta lo que te entregan. Si algo no cuadra con el sistema, queda anotado como diferencia del turno anterior.</p>' +
      '<label class="field"><span>¿Quién te entrega el bar?</span><input class="input" id="from" autocomplete="off" placeholder="Nombre de la persona" value="' + esc(UI.lastFrom || '') + '">' +
      '<div class="hint">Si es el primer turno, escribe "Inventario inicial".</div></label>',
    foot: '<button class="btn" data-close>Cancelar</button><button class="btn primary" id="go">' + ico('recibir') + 'Abrir y contar</button>',
    onMount(sh) {
      $('[data-close]', sh).onclick = () => closeSheet();
      $('#go', sh).onclick = () => {
        const from = $('#from', sh).value.trim();
        UI.lastFrom = from;
        openTurno(from);
        closeSheet(true);
        render();
        startCount('abrir');
      };
    },
  });
}

function screenTurno() {
  const t = S.turno;
  const v = $('#view');
  if (!t) {
    setTop('Turno', 'Sin turno abierto');
    const last = S.closed[S.closed.length - 1];
    v.innerHTML = '<div class="empty">' + ico('turno', 'i-xl') + '<h2>No hay turno abierto</h2><p>Cuando llegues al bar, recíbelo y cuenta. Al irte, entrégalo y vuelve a contar: esa es tu evidencia.</p>' +
      '<button class="btn primary big block" id="recv">' + ico('recibir') + 'Recibir el bar</button></div>' +
      (last ? '<div class="section-t">Último turno</div><button class="card li" id="lastT" style="width:100%"><div class="grow"><div class="t">' + esc(fechaLarga(last.date)) + '</div><div class="s">' + hora(last.openedAt) + ' a ' + hora(last.closedAt) + ' · ' + last.nSales + ' ventas</div></div><div class="v">' + money(last.total) + '</div>' + ico('derecha', 'i-sm') + '</button>' : '');
    $('#recv').onclick = () => startReceive();
    if (last) $('#lastT').onclick = () => openClosedTurno(last.id);
    return;
  }
  const s = summarize(t);
  const opened = t.counts.some(c => c.kind === 'abrir');
  setTop('Turno', esc(fechaLarga(t.date)));
  const tab = UI.turnoTab || 'ventas';
  v.innerHTML =
    '<div class="card"><div class="row"><span class="live" style="width:10px;height:10px;border-radius:5px;background:var(--ok);box-shadow:0 0 0 4px var(--ok-soft)" aria-hidden="true"></span>' +
    '<div class="grow"><b>Abierto desde las ' + hora(t.openedAt) + '</b><div class="muted small">' + (t.receivedFrom ? 'Recibido de ' + esc(t.receivedFrom) : 'Sin nombre de quien entregó') + '</div></div></div>' +
    '<div class="kpis"><div class="kpi"><div class="k">Ventas</div><div class="v">' + s.nSales + '</div></div>' +
    '<div class="kpi"><div class="k">Esperado</div><div class="v">' + money(s.total) + '</div></div>' +
    '<div class="kpi"><div class="k">Cortesías</div><div class="v">' + s.nCortesias + '</div></div></div></div>' +
    (opened ? '' : '<div class="banner" style="margin-top:12px">' + ico('alerta') + '<div class="grow">Todavía no contaste lo que recibiste.<div style="margin-top:8px"><button class="btn primary" id="cntOpen">Contar ahora</button></div></div></div>') +
    '<div class="actions">' +
    '<button class="action" id="aIng"><span class="ic">' + ico('ingreso') + '</span><span>Ingreso<div class="s">Llegó producto</div></span></button>' +
    '<button class="action" id="aCor"><span class="ic">' + ico('cortesia') + '</span><span>Cortesía<div class="s">O consumo del personal</div></span></button>' +
    '<button class="action" id="aBaj"><span class="ic">' + ico('rotura') + '</span><span>Rotura o merma<div class="s">Se rompió o se perdió</div></span></button>' +
    '<button class="action primary" id="aEnt"><span class="ic">' + ico('entregar') + '</span><span>Entregar el bar<div class="s">Contar y cerrar</div></span></button></div>' +
    '<div class="seg" role="tablist" style="margin-top:20px">' +
    [['ventas', 'Ventas'], ['movs', 'Movimientos'], ['conteos', 'Conteos']].map(([k, l]) => '<button role="tab" data-tab="' + k + '" aria-selected="' + (tab === k) + '">' + l + '</button>').join('') + '</div>' +
    '<div id="tabBody" style="margin-top:8px"></div>';
  if ($('#cntOpen')) $('#cntOpen').onclick = () => startCount('abrir');
  $('#aIng').onclick = () => openIngreso();
  $('#aCor').onclick = () => openCortesia();
  $('#aBaj').onclick = () => openBaja();
  $('#aEnt').onclick = () => startCount('cerrar');
  $$('[data-tab]', v).forEach(b => b.onclick = () => { UI.turnoTab = b.dataset.tab; $$('[data-tab]', v).forEach(x => x.setAttribute('aria-selected', x === b)); turnoTab(t); });
  turnoTab(t);
}

function turnoTab(t) {
  const el = $('#tabBody');
  const tab = UI.turnoTab || 'ventas';
  if (tab === 'ventas') {
    if (!t.sales.length) { el.innerHTML = '<div class="empty small">Todavía no hay ventas en este turno.</div>'; return; }
    el.innerHTML = '<div class="list">' + t.sales.slice().reverse().map(s =>
      '<button class="li' + (s.void ? ' void' : '') + '" data-sale="' + s.id + '"><div class="grow"><div class="t">Comanda ' + esc(s.comanda) + (s.void ? ' <span class="badge bad">Anulada</span>' : '') + '</div>' +
      '<div class="s ellipsis">' + hora(s.at) + ' · ' + esc(s.lines.map(l => l.qty + ' ' + l.name + (l.promo ? ' (2x1)' : '')).join(', ')) + '</div></div>' +
      '<div class="v">' + money(s.total) + '</div></button>').join('') + '</div>';
    $$('[data-sale]', el).forEach(b => b.onclick = () => openSale(b.dataset.sale));
  } else if (tab === 'movs') {
    const ms = t.movs.slice(-200).reverse();
    if (!ms.length) { el.innerHTML = '<div class="empty small">Sin movimientos todavía.</div>'; return; }
    el.innerHTML = '<div class="list">' + ms.map(movRow).join('') + '</div>' + (t.movs.length > 200 ? '<p class="muted small">Se muestran los 200 más recientes. El reporte del cierre los trae todos.</p>' : '');
  } else {
    if (!t.counts.length) { el.innerHTML = '<div class="empty small">Sin conteos en este turno.</div>'; return; }
    el.innerHTML = '<div class="list">' + t.counts.slice().reverse().map(c => {
      const items = Object.values(c.items);
      const d = items.filter(([a, b]) => Math.abs(a - b) > EPS).length;
      return '<button class="li" data-count="' + c.id + '"><div class="grow"><div class="t">' + (c.kind === 'abrir' ? 'Al recibir' : 'Al entregar') + '</div><div class="s">' + hora(c.at) + ' · ' + items.length + ' contados</div></div>' +
        '<span class="badge ' + (d ? 'acc' : 'ok') + '">' + (d ? d + ' diferencias' : 'Todo cuadra') + '</span>' + ico('derecha', 'i-sm') + '</button>';
    }).join('') + '</div>';
    $$('[data-count]', el).forEach(b => b.onclick = () => openCountDetail(t.counts.find(c => c.id === b.dataset.count)));
  }
}

function movRow(m) {
  const p = PROD[m.p];
  const sign = m.q > 0 ? '+' : '';
  const cls = m.q > 0 ? 'ok-t' : (m.t === 'conteo' || m.t === 'baja' ? 'bad-t' : '');
  return '<div class="li"><div class="grow"><div class="t ellipsis">' + esc(p ? p.name : m.p) + '</div><div class="s">' + hora(m.at) + ' · ' + esc(MOV_LABEL[m.t] || m.t) +
    (m.ref ? ' · ' + esc(m.ref) : '') + (m.note ? ' · ' + esc(m.note) : '') + '</div></div><div class="v ' + cls + '">' + sign + qty(m.q, 3) + ' <span class="muted small">' + (p ? unitShort(p) : '') + '</span></div></div>';
}

function openSale(id) {
  const s = S.turno.sales.find(x => x.id === id);
  const movs = S.turno.movs.filter(m => m.ref === id);
  openSheet({
    title: 'Comanda ' + s.comanda, sub: hora(s.at) + ' · ' + s.id + (s.void ? ' · anulada' : ''),
    body: (s.void ? '<div class="banner info">' + ico('anular') + '<div>Anulada a las ' + hora(s.void.at) + '. Motivo: ' + esc(s.void.reason) + '</div></div>' : '') +
      '<div class="list">' + s.lines.map(l => '<div class="li"><div class="grow"><div class="t">' + l.qty + ' × ' + esc(l.name) + '</div>' + (l.promo ? '<div class="s">2x1: salieron ' + l.units + '</div>' : '') + '</div><div class="v">' + money(l.total) + '</div></div>').join('') + '</div>' +
      '<div class="total-row"><span class="muted">Total</span><b>' + money(s.total) + '</b></div>' +
      '<div class="section-t">Lo que se descontó</div><div class="list">' + movs.map(movRow).join('') + '</div>',
    foot: s.void ? '<button class="btn" data-close>Cerrar</button>' : '<button class="btn danger" id="anular">' + ico('anular') + 'Anular venta</button>',
    onMount(sh) {
      if (s.void) { $('[data-close]', sh).onclick = () => closeSheet(); return; }
      $('#anular', sh).onclick = async () => {
        const reason = await askText({ title: 'Anular la comanda ' + s.comanda, label: '¿Por qué se anula?', hint: 'La venta no se borra: queda marcada como anulada con este motivo y el inventario se devuelve.', ok: 'Anular', danger: true });
        if (!reason) return;
        voidSale(id, reason);
        closeSheet();
        toast('Venta anulada. El inventario volvió a su lugar.');
        render();
      };
    },
  });
}

function openCountDetail(c) {
  const rows = Object.keys(c.items).map(pid => ({ pid, calc: c.items[pid][0], counted: c.items[pid][1] }))
    .filter(r => Math.abs(r.counted - r.calc) > EPS).sort((a, b) => (a.counted - a.calc) - (b.counted - b.calc));
  openSheet({
    title: c.kind === 'abrir' ? 'Conteo al recibir' : 'Conteo al entregar', sub: hora(c.at) + ' · ' + Object.keys(c.items).length + ' productos contados',
    body: rows.length ? rows.map(r => diffLine(r.pid, r.calc, r.counted)).join('') : '<div class="empty">' + ico('check', 'i-xl') + '<h2>Todo cuadra</h2><p>Lo contado coincide con el sistema.</p></div>',
  });
}
function diffLine(pid, calc, counted) {
  const p = PROD[pid]; const d = counted - calc;
  return '<div class="diff-line"><div class="grow"><div style="font-weight:650">' + esc(p.name) + '</div><div class="muted small">Sistema ' + qty(calc) + ' · contado ' + qty(counted) + ' ' + unitShort(p) + '</div></div>' +
    '<div class="' + (d < 0 ? 'bad-t' : 'info-t') + '" style="font-weight:800;white-space:nowrap">' + (d < 0 ? 'Faltan ' : 'Sobran ') + qty(Math.abs(d)) + ' ' + unitShort(p) + '</div></div>';
}

// ---------- Selector de productos ----------
function productPicker(container, onPick, filter) {
  container.innerHTML = '<div class="search">' + ico('buscar') + '<input class="input" type="search" placeholder="Buscar producto" aria-label="Buscar producto" autocomplete="off"></div><div class="list pp-list"></div>';
  const input = $('input', container), list = $('.pp-list', container);
  function draw() {
    const q = norm(input.value);
    let ps = S.products.filter(p => p.active !== false && (!filter || filter(p)));
    if (q) ps = ps.filter(p => norm(p.name + ' ' + p.cat).includes(q));
    ps = ps.slice(0, q ? 40 : 12);
    list.innerHTML = ps.map(p => '<button class="li" data-p="' + p.id + '"><div class="grow"><div class="t">' + esc(p.name) + '</div><div class="s">' + esc(p.cat) + ' · hay ' + stockText(p) + '</div></div>' + ico('mas1', 'i-sm') + '</button>').join('') ||
      '<div class="empty small">No hay productos con ese nombre.</div>';
    $$('[data-p]', list).forEach(b => b.onclick = () => { onPick(b.dataset.p); input.value = ''; draw(); });
  }
  input.oninput = draw;
  draw();
}
function itemPicker(container, onPick) {
  container.innerHTML = '<div class="search">' + ico('buscar') + '<input class="input" type="search" placeholder="Buscar en la carta" aria-label="Buscar en la carta" autocomplete="off"></div><div class="list ip-list"></div>';
  const input = $('input', container), list = $('.ip-list', container);
  function draw() {
    const q = norm(input.value);
    let its = S.items.filter(i => i.active !== false);
    its = q ? its.filter(i => norm(i.name + ' ' + (i.variant || '') + ' ' + i.cat).includes(q)).slice(0, 40) : frequentItems().map(id => ITEM[id]).concat(its.filter(i => i.cat === 'Cócteles')).slice(0, 12);
    list.innerHTML = its.map(i => '<button class="li" data-i="' + i.id + '"><div class="grow"><div class="t">' + esc(itemLabel(i)) + '</div><div class="s">' + esc(i.cat) + '</div></div>' + ico('mas1', 'i-sm') + '</button>').join('');
    $$('[data-i]', list).forEach(b => b.onclick = () => { onPick(b.dataset.i); input.value = ''; draw(); });
  }
  input.oninput = draw;
  draw();
}

// ---------- Ingreso de proveedor ----------
function openIngreso() {
  const lines = [];
  let firmo = null;
  function linesHtml() {
    if (!lines.length) return '<p class="muted small">Agrega lo que llegó con el buscador de abajo.</p>';
    return lines.map((l, i) => {
      const p = PROD[l.p];
      return '<div class="cart-line"><div class="grow"><div style="font-weight:650">' + esc(p.name) + '</div><div class="muted small">Hay ' + stockText(p) + '</div></div>' +
        '<div class="stepper"><button data-dec="' + i + '" aria-label="Menos">' + ico(l.q <= 1 ? 'basura' : 'menos1', 'i-sm') + '</button><span class="val">' + qty(l.q) + '</span><button data-inc="' + i + '" aria-label="Más">' + ico('mas1', 'i-sm') + '</button></div></div>';
    }).join('');
  }
  openSheet({
    title: 'Ingreso de producto', sub: 'Lo que entrega el proveedor',
    body: '<label class="field"><span>Proveedor</span><input class="input" id="prov" autocomplete="off" placeholder="Ej. Distribuidora"></label>' +
      '<div class="field"><span>¿Firmaste la nota de entrega?</span><div class="seg" id="firmo"><button data-f="si" aria-selected="false">Sí, firmé</button><button data-f="no" aria-selected="false">No firmé</button></div></div>' +
      '<div class="section-t" style="margin-top:8px">Productos</div><div id="ingLines">' + linesHtml() + '</div><div id="pp" style="margin-top:12px"></div>' +
      '<label class="field" style="margin-top:12px"><span>Nota (opcional)</span><input class="input" id="note" autocomplete="off"></label>',
    foot: '<button class="btn" data-close>Cancelar</button><button class="btn primary" id="save">' + ico('check') + 'Registrar ingreso</button>',
    onMount(sh) {
      $('[data-close]', sh).onclick = () => closeSheet();
      $$('[data-f]', sh).forEach(b => b.onclick = () => { firmo = b.dataset.f === 'si'; $$('[data-f]', sh).forEach(x => x.setAttribute('aria-selected', x === b)); });
      function redraw() {
        $('#ingLines', sh).innerHTML = linesHtml();
        $$('[data-inc]', sh).forEach(b => b.onclick = () => { lines[+b.dataset.inc].q++; redraw(); });
        $$('[data-dec]', sh).forEach(b => b.onclick = () => { const l = lines[+b.dataset.dec]; l.q--; if (l.q <= 0) lines.splice(+b.dataset.dec, 1); redraw(); });
      }
      productPicker($('#pp', sh), pid => { const l = lines.find(x => x.p === pid); if (l) l.q++; else lines.push({ p: pid, q: 1 }); haptic(); redraw(); });
      $('#save', sh).onclick = () => {
        if (!lines.length) { toast('Agrega al menos un producto'); return; }
        if (firmo === null) { toast('Marca si firmaste la nota de entrega'); return; }
        registerIngreso(lines, $('#prov', sh).value, firmo, $('#note', sh).value);
        closeSheet();
        celebrate('Ingreso registrado', lines.length + (lines.length === 1 ? ' producto' : ' productos'));
        render();
      };
    },
  });
}

// ---------- Cortesía ----------
function openCortesia() {
  const lines = [];
  let tipo = 'paquete', pad = null;
  function linesHtml() {
    if (!lines.length) return '<p class="muted small">Elige lo que se sirvió con el buscador de abajo.</p>';
    return lines.map((l, i) => '<div class="cart-line"><div class="grow" style="font-weight:650">' + esc(itemLabel(ITEM[l.item])) + '</div>' +
      '<div class="stepper"><button data-dec="' + i + '" aria-label="Menos">' + ico(l.qty <= 1 ? 'basura' : 'menos1', 'i-sm') + '</button><span class="val">' + l.qty + '</span><button data-inc="' + i + '" aria-label="Más">' + ico('mas1', 'i-sm') + '</button></div></div>').join('');
  }
  openSheet({
    title: 'Cortesía o consumo', sub: 'Sale del bar sin venta',
    body: '<div class="seg" id="tipo">' + Object.keys(CORTESIA_TIPOS).map(k => '<button data-t="' + k + '" aria-selected="' + (k === tipo) + '">' + ({ paquete: 'Paquete', feriado: 'Feriado', personal: 'Personal' })[k] + '</button>').join('') + '</div>' +
      '<p class="muted small" id="tipoTxt"></p>' +
      '<label class="field"><span id="autLbl">¿Quién la autoriza?</span><input class="input" id="aut" autocomplete="off" value="Recepción"></label>' +
      '<div id="lines">' + linesHtml() + '</div><div id="ip" style="margin-top:12px"></div>' +
      '<div id="firmaBox" class="field" style="margin-top:16px"><span>Firma de quien autoriza</span><canvas class="sign" id="sign" aria-label="Espacio para firmar"></canvas>' +
      '<div class="row" style="justify-content:space-between;margin-top:6px"><span class="hint">Firma con el dedo</span><button class="btn ghost small" id="clr">Borrar firma</button></div></div>',
    foot: '<button class="btn" data-close>Cancelar</button><button class="btn primary" id="save">' + ico('check') + 'Registrar</button>',
    onMount(sh) {
      $('[data-close]', sh).onclick = () => closeSheet();
      pad = signaturePad($('#sign', sh));
      $('#clr', sh).onclick = () => pad.clear();
      function syncTipo() {
        const d = CORTESIA_TIPOS[tipo];
        $('#firmaBox', sh).hidden = !d.firma;
        $('#tipoTxt', sh).textContent = tipo === 'paquete' ? 'Incluida en un paquete del hotel. Lleva la firma de recepción.' : tipo === 'feriado' ? 'Cortesía de feriado. No necesita firma.' : 'Lo que consume el personal del hotel.';
        $('#autLbl', sh).textContent = tipo === 'personal' ? '¿Quién lo consume o autoriza?' : '¿Quién la autoriza?';
      }
      $$('[data-t]', sh).forEach(b => b.onclick = () => { tipo = b.dataset.t; $$('[data-t]', sh).forEach(x => x.setAttribute('aria-selected', x === b)); syncTipo(); });
      syncTipo();
      function redraw() {
        $('#lines', sh).innerHTML = linesHtml();
        $$('[data-inc]', sh).forEach(b => b.onclick = () => { lines[+b.dataset.inc].qty++; redraw(); });
        $$('[data-dec]', sh).forEach(b => b.onclick = () => { const l = lines[+b.dataset.dec]; l.qty--; if (l.qty <= 0) lines.splice(+b.dataset.dec, 1); redraw(); });
      }
      itemPicker($('#ip', sh), id => { const l = lines.find(x => x.item === id); if (l) l.qty++; else lines.push({ item: id, qty: 1 }); haptic(); redraw(); });
      $('#save', sh).onclick = () => {
        const aut = $('#aut', sh).value.trim();
        if (!lines.length) { toast('Elige lo que se sirvió'); return; }
        if (!aut) { toast('Escribe quién la autoriza'); $('#aut', sh).focus(); return; }
        if (CORTESIA_TIPOS[tipo].firma && pad.empty()) { toast('Falta la firma de quien autoriza'); return; }
        registerCortesia(tipo, lines, aut, CORTESIA_TIPOS[tipo].firma ? pad.data() : '', '');
        closeSheet();
        celebrate('Cortesía registrada', CORTESIA_TIPOS[tipo].label);
        render();
      };
    },
  });
}

// ---------- Rotura o merma ----------
function openBaja() {
  let pid = null, motivo = 'rotura';
  openSheet({
    title: 'Rotura o merma', sub: 'Producto que se pierde',
    body: '<div id="sel"></div><div id="pp"></div>',
    foot: '<button class="btn" data-close>Cancelar</button><button class="btn danger" id="save" disabled>Registrar baja</button>',
    onMount(sh) {
      $('[data-close]', sh).onclick = () => closeSheet();
      function pick(id) {
        pid = id;
        const p = PROD[pid];
        $('#pp', sh).innerHTML = '';
        $('#sel', sh).innerHTML = '<div class="card" style="margin-bottom:16px"><div class="row"><div class="grow"><b>' + esc(p.name) + '</b><div class="muted small">Hay ' + stockText(p) + '</div></div><button class="btn ghost small" id="chg">Cambiar</button></div></div>' +
          '<label class="field"><span>Cantidad (' + esc(UNITS[p.unit] ? UNITS[p.unit][1] : p.unit) + ')</span><input class="input num" id="q" inputmode="decimal" value="1"><div class="hint">' + (partial(p) ? 'Puedes usar décimos: 0,5 es media ' + unitName(p, 1) + '.' : '') + '</div></label>' +
          '<div class="field"><span>Motivo</span><div class="seg">' + Object.keys(BAJA_MOTIVOS).map(k => '<button data-m="' + k + '" aria-selected="' + (k === motivo) + '">' + BAJA_MOTIVOS[k] + '</button>').join('') + '</div></div>' +
          '<label class="field"><span>Qué pasó (opcional)</span><input class="input" id="note" autocomplete="off"></label>';
        $('#chg', sh).onclick = () => { pid = null; $('#sel', sh).innerHTML = ''; $('#save', sh).disabled = true; productPicker($('#pp', sh), pick); };
        $$('[data-m]', sh).forEach(b => b.onclick = () => { motivo = b.dataset.m; $$('[data-m]', sh).forEach(x => x.setAttribute('aria-selected', x === b)); });
        $('#save', sh).disabled = false;
      }
      productPicker($('#pp', sh), pick);
      $('#save', sh).onclick = async () => {
        const q = num($('#q', sh).value);
        if (!(q > 0)) { toast('Escribe una cantidad mayor que cero'); return; }
        const p = PROD[pid];
        if (!await confirmSheet({ title: 'Registrar baja', text: 'Sale del inventario ' + qty(q) + ' ' + unitName(p, q) + ' de ' + esc(p.name) + ' por ' + BAJA_MOTIVOS[motivo].toLowerCase() + '.', ok: 'Registrar', danger: true })) return;
        registerBaja(pid, q, motivo, $('#note', sh).value);
        closeSheet();
        toast('Baja registrada');
        render();
      };
    },
  });
}

// =====================================================================
// INVENTARIO
// =====================================================================
function screenInventario() {
  const neg = S.products.filter(p => p.stock < -EPS).length;
  const zero = S.products.filter(p => Math.abs(p.stock) <= EPS).length;
  setTop('Inventario', S.products.length + ' productos · ' + zero + ' en cero' + (neg ? ' · <span class="bad-t">' + neg + ' en negativo</span>' : ''));
  const cats = ['Todos', 'Por confirmar'].concat(sortCats(Array.from(new Set(S.products.map(p => p.cat))), PROD_CATS));
  if (neg) cats.splice(1, 0, 'En negativo');
  if (!UI.invCat || cats.indexOf(UI.invCat) < 0) UI.invCat = 'Todos';
  const v = $('#view');
  v.innerHTML = '<div class="sell-head"><div class="search">' + ico('buscar') + '<input class="input" id="iq" type="search" placeholder="Buscar producto" aria-label="Buscar producto" value="' + esc(UI.invQ || '') + '" autocomplete="off"></div>' +
    '<div class="chips">' + cats.map(c => '<button class="chip" data-cat="' + esc(c) + '" aria-pressed="' + (c === UI.invCat) + '">' + esc(c) + '</button>').join('') + '</div></div>' +
    '<div class="list" id="inv"></div>' +
    '<p class="muted small" style="margin-top:16px">El stock solo cambia con ventas, ingresos, cortesías, bajas y conteos. Así cada número tiene su respaldo.</p>';
  function draw() {
    const q = norm(UI.invQ);
    let ps = S.products.filter(p => p.active !== false);
    if (q) ps = ps.filter(p => norm(p.name + ' ' + p.cat).includes(q));
    else if (UI.invCat === 'Por confirmar') ps = ps.filter(p => (p.pend || []).length);
    else if (UI.invCat === 'En negativo') ps = ps.filter(p => p.stock < -EPS);
    else if (UI.invCat !== 'Todos') ps = ps.filter(p => p.cat === UI.invCat);
    $('#inv').innerHTML = ps.map(p => {
      const low = p.min && p.stock < p.min;
      return '<button class="li" data-p="' + p.id + '">' +
        thumb(p, 44) +
        '<div class="grow"><div class="t">' + esc(p.name) + '</div><div class="s">' + esc(p.cat) + ((p.pend || []).length ? ' · <span class="acc-t">por confirmar</span>' : '') + (low ? ' · <span class="bad-t">bajo el mínimo</span>' : '') + '</div></div>' +
        '<div class="stock"><div class="q ' + (p.stock < -EPS ? 'bad-t' : '') + '">' + qty(p.stock) + '</div><div class="u">' + esc(unitShort(p)) + '</div></div></button>';
    }).join('') || '<div class="empty">' + ico('buscar', 'i-xl') + '<h2>Sin productos</h2></div>';
    $$('[data-p]', $('#inv')).forEach(b => b.onclick = () => openProduct(b.dataset.p));
  }
  draw();
  $('#iq').oninput = e => { UI.invQ = e.target.value; draw(); };
  $$('.chip', v).forEach(c => c.onclick = () => { UI.invCat = c.dataset.cat; $$('.chip', v).forEach(x => x.setAttribute('aria-pressed', x === c)); UI.invQ = ''; $('#iq').value = ''; draw(); });
}

function convSentences(p) {
  const c = p.conv || {}, out = [];
  const u = unitName(p, 1);
  if (c.oz) out.push('1 ' + u + ' = ' + qty(c.oz) + ' oz');
  if (c.und > 1) out.push('1 ' + u + ' = ' + qty(c.und) + ' piezas');
  if (c.ozPieza) out.push('1 pieza = ' + qty(c.ozPieza) + ' oz de jugo');
  if (c.cda) out.push('1 ' + u + ' = ' + qty(c.cda) + ' cucharadas');
  if (c.g) out.push('1 ' + u + ' = ' + qty(c.g) + ' g');
  return out;
}

function openProduct(pid, startTab) {
  const p = PROD[pid];
  let tab = startTab || 'resumen';
  openSheet({
    title: p.name, sub: p.cat + ' · se cuenta por ' + unitName(p, 1),
    body: '<div class="seg" role="tablist">' + [['resumen', 'Resumen'], ['movs', 'Movimientos'], ['editar', 'Editar']].map(([k, l]) => '<button role="tab" data-tab="' + k + '" aria-selected="' + (k === tab) + '">' + l + '</button>').join('') + '</div><div id="pb" style="margin-top:12px"></div>',
    onClose() { PROD_REDRAW = null; },
    onMount(sh) {
      const tabs = $$('[data-tab]', sh);
      tabs.forEach(b => b.onclick = () => { tab = b.dataset.tab; tabs.forEach(x => x.setAttribute('aria-selected', x === b)); draw(); });
      PROD_REDRAW = () => { if (tab === 'resumen') draw(); };
      function draw() {
        const el = $('#pb', sh);
        if (tab === 'resumen') {
          const uses = S.items.filter(i => (i.lines || []).some(l => l.p === pid));
          const oz = ozPer(p);
          el.innerHTML = '<div class="prod-hero">' + thumb(p, 76) + '<div class="grow"><div style="font-weight:700;font-size:17px">' + esc(p.name) + '</div>' +
            '<div class="row" style="gap:8px;margin-top:8px">' + (NATIVE ?
              '<button class="btn small" id="setPhoto">' + ico(p.img ? 'editar' : 'botella', 'i-sm') + (p.img ? 'Cambiar foto' : 'Poner foto') + '</button>' +
              (p.img ? '<button class="btn ghost small bad-t" id="rmPhoto">Quitar</button>' : '') :
              '<span class="muted tiny">Pon fotos desde el celular</span>') + '</div></div></div>' +
            '<div class="card"><div class="muted small">En el sistema</div><div class="big-total ' + (p.stock < -EPS ? 'bad-t' : '') + '">' + qty(p.stock) + ' <span style="font-size:18px">' + esc(unitName(p, p.stock)) + '</span></div>' +
            (oz ? '<div class="muted small">≈ ' + qty(p.stock * oz, 1) + ' oz en total</div>' : '') + '</div>' +
            ((p.pend || []).length ? '<div class="section-t">Por confirmar</div>' + p.pend.map((t, i) => '<div class="banner"><div class="grow">' + esc(t) + '</div><button class="btn small" data-ok="' + i + '">Confirmado</button></div>').join('') : '') +
            '<div class="section-t">Conversión</div>' + (convSentences(p).map(s => '<div class="small" style="padding:4px 0">' + esc(s) + '</div>').join('') || '<div class="muted small">Se resta por ' + esc(unitName(p, 1)) + ' entera.</div>') +
            '<div class="section-t">Se usa en</div>' + (uses.length ? '<div class="small">' + uses.map(i => esc(itemLabel(i))).join(', ') + '</div>' : '<div class="muted small">Ningún ítem de la carta.</div>');
          $$('[data-ok]', el).forEach(b => b.onclick = () => { p.pend.splice(+b.dataset.ok, 1); saveState(); draw(); toast('Marcado como confirmado'); });
          if ($('#setPhoto', el)) $('#setPhoto', el).onclick = () => setPhoto(p.id);
          if ($('#rmPhoto', el)) $('#rmPhoto', el).onclick = () => { delete p.img; saveState(); draw(); render(); toast('Foto quitada'); };
        } else if (tab === 'movs') {
          const cur = S.turno ? S.turno.movs.filter(m => m.p === pid).reverse() : [];
          let html = '<div class="section-t">Turno actual</div>' + (cur.length ? '<div class="list">' + cur.map(movRow).join('') + '</div>' : '<div class="muted small">Sin movimientos en este turno.</div>');
          S.closed.slice(-5).reverse().forEach(c => {
            const t = loadTurnoFile(c.id);
            const ms = t ? t.movs.filter(m => m.p === pid).reverse() : [];
            if (ms.length) html += '<div class="section-t">' + esc(fechaLarga(c.date)) + '</div><div class="list">' + ms.map(movRow).join('') + '</div>';
          });
          el.innerHTML = html;
        } else {
          el.innerHTML = productForm(p);
          bindProductForm(el, p, () => { closeSheet(); render(); toast('Producto guardado'); });
        }
      }
      draw();
    },
  });
}

function productForm(p) {
  const c = p.conv || {};
  const cats = sortCats(Array.from(new Set(S.products.map(x => x.cat).concat(PROD_CATS))), PROD_CATS);
  return '<label class="field"><span>Nombre</span><input class="input" name="name" value="' + esc(p.name) + '" autocomplete="off"></label>' +
    '<div class="grid2"><label class="field"><span>Categoría</span><select class="input" name="cat">' + cats.map(k => '<option' + (k === p.cat ? ' selected' : '') + '>' + esc(k) + '</option>').join('') + '</select></label>' +
    '<label class="field"><span>Se cuenta por</span><select class="input" name="unit">' + Object.keys(UNITS).map(k => '<option value="' + k + '"' + (k === p.unit ? ' selected' : '') + '>' + UNITS[k][0] + '</option>').join('') + '</select></label></div>' +
    '<div class="section-t" style="margin-top:4px">Conversión para las recetas</div>' +
    '<div class="grid2"><label class="field"><span>Onzas por unidad</span><input class="input num" name="oz" inputmode="decimal" value="' + (c.oz ? qty(c.oz) : '') + '" placeholder="750 ml = 25"></label>' +
    '<label class="field"><span>Piezas por unidad</span><input class="input num" name="und" inputmode="decimal" value="' + (c.und ? qty(c.und) : '') + '" placeholder="Ej. limones"></label>' +
    '<label class="field"><span>Onzas por pieza</span><input class="input num" name="ozPieza" inputmode="decimal" value="' + (c.ozPieza ? qty(c.ozPieza) : '') + '" placeholder="Jugo por limón"></label>' +
    '<label class="field"><span>Cucharadas por unidad</span><input class="input num" name="cda" inputmode="decimal" value="' + (c.cda ? qty(c.cda) : '') + '"></label>' +
    '<label class="field"><span>Gramos por unidad</span><input class="input num" name="g" inputmode="decimal" value="' + (c.g ? qty(c.g) : '') + '"></label>' +
    '<label class="field"><span>Mínimo (aviso)</span><input class="input num" name="min" inputmode="decimal" value="' + (p.min ? qty(p.min) : '') + '"></label></div>' +
    '<button class="btn primary block" id="pSave">' + ico('check') + 'Guardar producto</button>';
}
function bindProductForm(el, p, done) {
  $('#pSave', el).onclick = () => {
    const f = n => $('[name="' + n + '"]', el).value;
    const name = f('name').trim();
    if (!name) { toast('El nombre no puede quedar vacío'); return; }
    p.name = name; p.cat = f('cat'); p.unit = f('unit');
    const conv = {};
    ['oz', 'und', 'ozPieza', 'cda', 'g'].forEach(k => { const v = num(f(k)); if (v > 0) conv[k] = v; });
    p.conv = conv;
    const mn = num(f('min')); p.min = mn > 0 ? mn : 0;
    if (!PROD[p.id]) { S.products.push(p); }
    index(); saveState(); done();
  };
}
function openNewProduct() {
  const p = { id: 'P' + pad(++S.seq.prod, 3), name: '', raw: '', cat: 'Insumos', unit: 'unidad', conv: {}, stock: 0, min: 0, cost: 0, pend: [] };
  openSheet({
    title: 'Nuevo producto', sub: 'Empieza en 0: súmalo con un ingreso o un conteo',
    body: productForm(p),
    onMount(sh) { bindProductForm($('.sheet-b', sh), p, () => { closeSheet(); render(); toast('Producto creado'); }); },
  });
}

// =====================================================================
// REPORTES
// =====================================================================
function dayEntries() {
  const days = {};
  S.closed.forEach(c => (days[c.date] = days[c.date] || []).push(c));
  if (S.turno) {
    const s = summarize(S.turno);
    (days[S.turno.date] = days[S.turno.date] || []).push(Object.assign({ live: true, id: S.turno.id, date: S.turno.date }, s));
  }
  return days;
}
function mergeEntries(list) {
  const out = { total: 0, nSales: 0, nVoid: 0, nCortesias: 0, byItem: {}, byProd: {} };
  list.forEach(e => {
    out.total = r2(out.total + e.total); out.nSales += e.nSales; out.nVoid += e.nVoid || 0; out.nCortesias += e.nCortesias || 0;
    Object.keys(e.byItem || {}).forEach(id => { const a = out.byItem[id] || (out.byItem[id] = { name: e.byItem[id].name, qty: 0, total: 0 }); a.qty += e.byItem[id].qty; a.total = r2(a.total + e.byItem[id].total); });
    Object.keys(e.byProd || {}).forEach(id => { const a = out.byProd[id] || (out.byProd[id] = { ingresa: 0, sale: 0, cortesia: 0, uso: 0, baja: 0, conteo: 0 }); Object.keys(a).forEach(k => a[k] = r4(a[k] + (e.byProd[id][k] || 0))); });
  });
  return out;
}
function barsHtml(rows, valKey, fmt) {
  if (!rows.length) return '<div class="empty small">Sin ventas en este periodo.</div>';
  const max = Math.max.apply(null, rows.map(r => r[valKey])) || 1;
  return rows.map(r => '<div class="bar-row"><div class="ellipsis" style="font-weight:600">' + esc(r.name) + '</div><div class="num" style="font-weight:750">' + fmt(r) + '</div>' +
    '<div class="bar"><i style="width:' + Math.max(2, Math.round(r[valKey] / max * 100)) + '%"></i></div></div>').join('');
}

function screenReportes() {
  setTop('Reportes', 'Ventas y salidas por día y por producto');
  const tab = UI.repTab || 'dia';
  const v = $('#view');
  v.innerHTML = '<div class="seg" role="tablist">' + [['dia', 'Por día'], ['prod', 'Por producto'], ['turnos', 'Turnos']].map(([k, l]) => '<button role="tab" data-tab="' + k + '" aria-selected="' + (tab === k) + '">' + l + '</button>').join('') + '</div><div id="rb" style="margin-top:12px"></div>';
  $$('[data-tab]', v).forEach(b => b.onclick = () => { UI.repTab = b.dataset.tab; screenReportes(); });
  const el = $('#rb');
  const days = dayEntries();
  const dates = Object.keys(days).sort().reverse();
  if (tab === 'dia') {
    if (!dates.length) { el.innerHTML = '<div class="empty">' + ico('reportes', 'i-xl') + '<h2>Aún no hay ventas</h2><p>Cuando registres ventas, aquí verás cuánto vendiste cada día y de qué.</p></div>'; return; }
    if (!UI.repDay || !days[UI.repDay]) UI.repDay = dates[0];
    const d = mergeEntries(days[UI.repDay]);
    const rows = Object.values(d.byItem).sort((a, b) => b.total - a.total);
    el.innerHTML = '<div class="chips">' + dates.slice(0, 40).map(k => { const [y, m, dd] = k.split('-'); const wd = DIAS[new Date(+y, +m - 1, +dd).getDay()].slice(0, 3); return '<button class="chip day-chip" data-day="' + k + '" aria-pressed="' + (k === UI.repDay) + '"><span class="tiny">' + wd + '</span><b>' + (+dd) + ' ' + MESES[+m - 1].slice(0, 3) + '</b></button>'; }).join('') + '</div>' +
      '<div class="card"><div class="muted small">' + esc(fechaLarga(UI.repDay)) + (days[UI.repDay].some(e => e.live) ? ' · turno abierto' : '') + '</div><div class="big-total">' + money(d.total) + '</div>' +
      '<div class="muted small">' + d.nSales + ' ventas' + (d.nVoid ? ' · ' + d.nVoid + ' anuladas' : '') + (d.nCortesias ? ' · ' + d.nCortesias + ' cortesías' : '') + '</div></div>' +
      '<div class="section-t">Lo que más se vendió</div>' + barsHtml(rows, 'total', r => r.qty + ' · ' + money(r.total));
    $$('[data-day]', el).forEach(b => b.onclick = () => { UI.repDay = b.dataset.day; screenReportes(); });
  } else if (tab === 'prod') {
    const per = UI.repPer || 7;
    const mode = UI.repMode || 'carta';
    const limit = per === 'todo' ? '' : isoDay(Date.now() - (per - 1) * 86400000);
    const list = [];
    dates.filter(k => !limit || k >= limit).forEach(k => days[k].forEach(e => list.push(e)));
    const d = mergeEntries(list);
    let rows;
    if (mode === 'carta') rows = Object.values(d.byItem).sort((a, b) => b.qty - a.qty);
    else rows = Object.keys(d.byProd).map(id => { const e = d.byProd[id]; const p = PROD[id]; return { name: p ? p.name : id, out: r4(e.sale + e.uso + e.cortesia + e.baja), e, p }; }).filter(r => r.out > EPS).sort((a, b) => b.out - a.out);
    el.innerHTML = '<div class="chips">' + [[1, 'Hoy'], [7, '7 días'], [30, '30 días'], ['todo', 'Todo']].map(([k, l]) => '<button class="chip" data-per="' + k + '" aria-pressed="' + (String(k) === String(per)) + '">' + l + '</button>').join('') + '</div>' +
      '<div class="seg" style="margin-bottom:8px">' + [['carta', 'De la carta'], ['inv', 'Del inventario']].map(([k, l]) => '<button data-mode="' + k + '" aria-selected="' + (k === mode) + '">' + l + '</button>').join('') + '</div>' +
      '<p class="muted small">' + (mode === 'carta' ? 'Cuántas veces se vendió cada cosa y cuánto dinero dejó.' : 'Cuánto salió de cada producto: ventas, cócteles, cortesías y bajas.') + '</p>' +
      (mode === 'carta' ? barsHtml(rows, 'qty', r => r.qty + ' · ' + money(r.total)) : barsHtml(rows, 'out', r => qty(r.out) + ' ' + (r.p ? unitShort(r.p) : '')));
    $$('[data-per]', el).forEach(b => b.onclick = () => { UI.repPer = b.dataset.per === 'todo' ? 'todo' : +b.dataset.per; screenReportes(); });
    $$('[data-mode]', el).forEach(b => b.onclick = () => { UI.repMode = b.dataset.mode; screenReportes(); });
  } else {
    if (!S.closed.length) { el.innerHTML = '<div class="empty">' + ico('turno', 'i-xl') + '<h2>Sin turnos cerrados</h2><p>Al entregar el bar se guarda el turno con su PDF de cierre.</p></div>'; return; }
    el.innerHTML = '<div class="list">' + S.closed.slice().reverse().map(c => {
      const dif = (c.diffs && (c.diffs.abrir + c.diffs.cerrar)) || 0;
      return '<button class="li" data-t="' + c.id + '"><div class="grow"><div class="t">' + esc(fechaLarga(c.date)) + '</div><div class="s">' + hora(c.openedAt) + ' a ' + hora(c.closedAt) + ' · ' + c.nSales + ' ventas' + (dif ? ' · <span class="acc-t">' + dif + ' diferencias</span>' : '') + '</div></div><div class="v">' + money(c.total) + '</div>' + ico('derecha', 'i-sm') + '</button>';
    }).join('') + '</div>';
    $$('[data-t]', el).forEach(b => b.onclick = () => openClosedTurno(b.dataset.t));
  }
}

function openClosedTurno(id) {
  const c = S.closed.find(x => x.id === id);
  openSheet({
    title: 'Turno del ' + fechaLarga(c.date), sub: hora(c.openedAt) + ' a ' + hora(c.closedAt) + ' · cerrado, no se puede cambiar',
    body: '<div class="kpis" style="margin-top:0"><div class="kpi"><div class="k">Ventas</div><div class="v">' + c.nSales + '</div></div><div class="kpi"><div class="k">Esperado</div><div class="v">' + money(c.total) + '</div></div><div class="kpi"><div class="k">Cortesías</div><div class="v">' + (c.nCortesias || 0) + '</div></div></div>' +
      '<div class="list" style="margin-top:12px"><div class="li"><div class="grow">Recibido de</div><b>' + esc(c.receivedFrom || '—') + '</b></div><div class="li"><div class="grow">Entregado a</div><b>' + esc(c.handedTo || '—') + '</b></div>' +
      '<div class="li"><div class="grow">Diferencias al recibir</div><b>' + ((c.diffs && c.diffs.abrir) || 0) + '</b></div><div class="li"><div class="grow">Diferencias al entregar</div><b>' + ((c.diffs && c.diffs.cerrar) || 0) + '</b></div></div>',
    foot: '<button class="btn" id="ver">' + ico('pdf') + 'Ver</button><button class="btn" id="csv">' + ico('tabla') + 'Excel</button><button class="btn primary" id="env">' + ico('enviar') + 'Enviar</button>',
    onMount(sh) {
      const t = () => loadTurnoFile(id);
      $('#ver', sh).onclick = () => viewReport(t());
      $('#env', sh).onclick = () => sharePdf(t());
      $('#csv', sh).onclick = () => exportCsv(t());
    },
  });
}

// =====================================================================
// MÁS
// =====================================================================
function pendCount() {
  return S.products.filter(p => (p.pend || []).length).length + S.items.filter(i => (i.pend || []).some(x => x !== 'Precio de prueba')).length + (S.settings.pricesOk ? 0 : 1);
}
function screenMas() {
  setTop('Más', esc(S.settings.bar) + ' · ' + esc(S.settings.responsable || ''));
  const n = pendCount();
  $('#view').innerHTML = '<div class="grid2">' +
    tool('carta', 'Carta y precios', 'Precios de venta y recetas de cada trago', 'carta') +
    tool('pend', 'Datos por confirmar', 'Lo que falta que Adriana confirme', 'pendiente', n ? '<span class="badge acc">' + n + '</span>' : '') +
    tool('nuevo', 'Nuevo producto', 'Algo que no estaba en el inventario', 'nuevo') +
    tool('csv', 'Exportar a Excel', 'Columnas como tu hoja: ingresa, sale, cortesía, uso', 'tabla') +
    tool('resp', 'Respaldo', 'Guardar o recuperar todo en un archivo', 'escudo') +
    tool('updates', 'Actualizaciones', 'Buscar e instalar mejoras de la app', 'bajar') +
    tool('terms', 'Términos y permisos', 'Qué hace la app y qué usa de tu celular', 'candado') +
    tool('ajustes', 'Ajustes', 'Tu nombre, PIN, bloqueo y tema', 'ajustes') +
    '</div><p class="muted small" style="text-align:center;margin-top:24px">Arqueo Bar ' + (NATIVE ? Android.version() : 'web') + ' · interfaz v' + (window.APP_BUILD || 1) + '<br>Tus datos se guardan solo en este celular.</p>';
  $$('[data-tool]').forEach(b => b.onclick = () => ({
    carta: openCarta, pend: openPendientes, nuevo: openNewProduct, csv: () => exportCsv(S.turno || (S.closed.length ? loadTurnoFile(S.closed[S.closed.length - 1].id) : null)), resp: openRespaldo, updates: openUpdates, terms: () => openTerms(false), ajustes: openAjustes,
  })[b.dataset.tool]());
}
function tool(id, t, s, icon, extra) {
  return '<button class="tool" data-tool="' + id + '"><span class="ic">' + ico(icon) + '</span><span><span class="t">' + esc(t) + '</span><div class="s">' + esc(s) + '</div></span>' + (extra || '') + '</button>';
}

// ---------- Carta y precios ----------
function openCarta() {
  let cat = 'Cócteles';
  openSheet({
    full: true, title: 'Carta y precios', sub: S.items.length + ' ítems',
    head: '<button class="icon-btn" id="newItem" aria-label="Nuevo ítem">' + ico('nuevo') + '</button>',
    body: '<div id="cb"></div>',
    onClose() { render(); },
    onMount(sh) {
      $('#newItem', sh).onclick = () => openItem(null, draw);
      function draw() {
        const cats = sortCats(Array.from(new Set(S.items.map(i => i.cat))), CAT_ORDER);
        $('#cb', sh).innerHTML =
          (S.settings.pricesOk ? '<div class="banner info">' + ico('check') + '<div class="grow">Precios confirmados con la carta del hotel.</div></div>' :
            '<div class="banner">' + ico('alerta') + '<div class="grow">Estos precios son de prueba. Corrígelos con la carta del hotel y luego confírmalos.<div style="margin-top:8px"><button class="btn primary" id="pOk">Ya están bien los precios</button></div></div></div>') +
          '<div class="chips">' + cats.map(c => '<button class="chip" data-cat="' + esc(c) + '" aria-pressed="' + (c === cat) + '">' + esc(c) + '</button>').join('') + '</div>' +
          '<div class="list">' + S.items.filter(i => i.cat === cat).map(i =>
            '<div class="li"><button class="grow" style="text-align:left" data-edit="' + i.id + '"><div class="t">' + esc(itemLabel(i)) + (i.active === false ? ' <span class="badge">Oculto</span>' : '') + '</div><div class="s ellipsis">' + esc((i.lines || []).map(lineText).join(', ') || 'Sin receta') + '</div></button>' +
            '<label class="sr" for="pr' + i.id + '">Precio de ' + esc(itemLabel(i)) + '</label><input class="input num" id="pr' + i.id + '" data-price="' + i.id + '" inputmode="decimal" style="width:96px;text-align:right" value="' + qty(i.price) + '"></div>').join('') + '</div>';
        if ($('#pOk', sh)) $('#pOk', sh).onclick = async () => {
          if (!await confirmSheet({ title: 'Confirmar precios', text: 'Se quita el aviso de "precio de prueba" de toda la carta.', ok: 'Confirmar' })) return;
          S.settings.pricesOk = true;
          S.items.forEach(i => i.pend = (i.pend || []).filter(x => x !== 'Precio de prueba'));
          saveState(); draw();
        };
        $$('[data-cat]', sh).forEach(b => b.onclick = () => { cat = b.dataset.cat; draw(); });
        $$('[data-edit]', sh).forEach(b => b.onclick = () => openItem(b.dataset.edit, draw));
        $$('[data-price]', sh).forEach(inp => inp.onchange = () => {
          const v = num(inp.value), it = ITEM[inp.dataset.price];
          if (!(v >= 0)) { inp.value = qty(it.price); toast('Precio no válido'); return; }
          it.price = r2(v); saveState(); inp.value = qty(it.price); toast(itemLabel(it) + ': ' + money(it.price));
        });
      }
      draw();
    },
  });
}

function openItem(id, after) {
  const it = id ? JSON.parse(JSON.stringify(ITEM[id])) : { id: 'X' + pad(++S.seq.item, 3), name: '', cat: 'Cócteles', price: 0, lines: [], pend: [] };
  const cats = sortCats(Array.from(new Set(S.items.map(i => i.cat).concat(CAT_ORDER))), CAT_ORDER);
  function linesHtml() {
    return (it.lines.length ? it.lines.map((l, i) => {
      const p = PROD[l.p];
      if (!p) return '<div class="cart-line"><div class="grow muted">' + esc(lineText(l)) + '<div class="tiny">No está en el inventario: no se descuenta</div></div><button class="icon-btn" data-del="' + i + '" aria-label="Quitar">' + ico('basura', 'i-sm') + '</button></div>';
      const conv = unitsFor(l, 1);
      return '<div class="cart-line"><div class="grow"><div style="font-weight:650">' + esc(p.name) + '</div><div class="tiny ' + (conv == null ? 'bad-t' : 'muted') + '">' + (conv == null ? 'Falta la conversión en el producto' : 'Resta ' + qty(conv, 3) + ' ' + unitShort(p)) + '</div></div>' +
        '<button class="icon-btn" data-del="' + i + '" aria-label="Quitar">' + ico('basura', 'i-sm') + '</button>' +
        '<div class="row" style="grid-column:1/-1"><input class="input num" data-q="' + i + '" inputmode="decimal" value="' + qty(l.q) + '" style="width:110px" aria-label="Cantidad">' +
        '<select class="input" data-u="' + i + '" aria-label="Unidad">' + [['u', unitName(p, 1)], ['oz', 'onzas'], ['und', 'piezas'], ['cda', 'cucharadas'], ['g', 'gramos']].map(([k, lab]) => '<option value="' + k + '"' + (k === l.u ? ' selected' : '') + '>' + esc(lab) + '</option>').join('') + '</select></div></div>';
    }).join('') : '<p class="muted small">Sin ingredientes: no descuenta nada al venderse.</p>');
  }
  openSheet({
    full: true, title: id ? itemLabel(ITEM[id]) : 'Nuevo ítem', sub: 'Lo que se vende y lo que descuenta',
    body: '<label class="field"><span>Nombre</span><input class="input" id="nm" value="' + esc(it.name) + '" autocomplete="off"></label>' +
      '<div class="grid2"><label class="field"><span>Presentación</span><input class="input" id="vr" value="' + esc(it.variant || '') + '" placeholder="Trago, botella, copa…" autocomplete="off"></label>' +
      '<label class="field"><span>Precio</span><input class="input num" id="pr" inputmode="decimal" value="' + qty(it.price) + '"></label></div>' +
      '<label class="field"><span>Categoría</span><select class="input" id="ct">' + cats.map(k => '<option' + (k === it.cat ? ' selected' : '') + '>' + esc(k) + '</option>').join('') + '</select></label>' +
      '<label class="row" style="min-height:48px"><input type="checkbox" id="ac" ' + (it.active === false ? '' : 'checked') + ' style="width:22px;height:22px;accent-color:var(--accent)"> <span>Mostrar en Vender</span></label>' +
      ((it.pend || []).length ? '<div class="section-t">Por confirmar</div>' + it.pend.map((t, i) => '<div class="banner"><div class="grow">' + esc(t) + '</div><button class="btn small" data-ok="' + i + '">Confirmado</button></div>').join('') : '') +
      '<div class="section-t">Receta (lo que se descuenta por cada uno)</div><div id="ln">' + linesHtml() + '</div><div class="section-t">Agregar ingrediente</div><div id="pp"></div>',
    foot: '<button class="btn" data-close>Cancelar</button><button class="btn primary" id="sv">' + ico('check') + 'Guardar</button>',
    onMount(sh) {
      $('[data-close]', sh).onclick = () => closeSheet();
      function bind() {
        $$('[data-del]', sh).forEach(b => b.onclick = () => { it.lines.splice(+b.dataset.del, 1); redraw(); });
        $$('[data-q]', sh).forEach(inp => inp.onchange = () => { const v = num(inp.value); if (v > 0) it.lines[+inp.dataset.q].q = v; redraw(); });
        $$('[data-u]', sh).forEach(sel => sel.onchange = () => { it.lines[+sel.dataset.u].u = sel.value; redraw(); });
        $$('[data-ok]', sh).forEach(b => b.onclick = () => { it.pend.splice(+b.dataset.ok, 1); b.closest('.banner').remove(); });
      }
      function redraw() { $('#ln', sh).innerHTML = linesHtml(); bind(); }
      bind();
      productPicker($('#pp', sh), pid => { const p = PROD[pid]; it.lines.push({ p: pid, q: 1, u: ozPer(p) ? 'oz' : 'u' }); redraw(); });
      $('#sv', sh).onclick = () => {
        it.name = $('#nm', sh).value.trim();
        it.variant = $('#vr', sh).value.trim() || undefined;
        it.cat = $('#ct', sh).value;
        it.active = $('#ac', sh).checked ? undefined : false;
        const price = num($('#pr', sh).value);
        if (!it.name) { toast('Falta el nombre'); return; }
        if (!(price >= 0)) { toast('Precio no válido'); return; }
        it.price = r2(price);
        if (id) Object.assign(ITEM[id], it); else S.items.push(it);
        index(); saveState(); closeSheet(true); toast('Guardado'); after && after();
      };
    },
  });
}

// ---------- Datos por confirmar ----------
function openPendientes() {
  openSheet({
    full: true, title: 'Datos por confirmar', sub: 'Valores de prueba hasta que Adriana los confirme',
    body: '<div id="pb"></div>',
    onClose() { render(); },
    onMount(sh) {
      function draw() {
        const prods = S.products.filter(p => (p.pend || []).length);
        const recs = S.items.filter(i => (i.pend || []).some(x => x !== 'Precio de prueba'));
        const precios = S.items.filter(i => (i.pend || []).includes('Precio de prueba')).length;
        $('#pb', sh).innerHTML =
          '<div class="section-t" style="margin-top:0">Medidas</div><div class="card">' +
          '<div class="grid2"><label class="field"><span>Onzas del trago solo</span><input class="input num" id="toz" inputmode="decimal" value="' + qty(S.settings.tragoOz) + '"></label>' +
          '<label class="field"><span>Onzas de la copa de vino</span><input class="input num" id="coz" inputmode="decimal" value="' + qty(S.settings.copaOz) + '"></label></div>' +
          '<button class="btn block" id="apl">Aplicar a todos los tragos y copas</button></div>' +
          '<div class="section-t">Precios</div><button class="card li" id="goCarta" style="width:100%"><div class="grow"><div class="t">' + (S.settings.pricesOk ? 'Precios confirmados' : precios + ' precios de prueba') + '</div><div class="s">Cárgalos con la carta del hotel</div></div>' + ico('derecha', 'i-sm') + '</button>' +
          '<div class="section-t">Recetas (' + recs.length + ')</div>' + (recs.length ? '<div class="list">' + recs.map(i => '<button class="li" data-item="' + i.id + '"><div class="grow"><div class="t">' + esc(itemLabel(i)) + '</div><div class="s">' + esc(i.pend.filter(x => x !== 'Precio de prueba').join(' · ')) + '</div></div>' + ico('derecha', 'i-sm') + '</button>').join('') + '</div>' : '<p class="muted small">Nada pendiente.</p>') +
          '<div class="section-t">Productos (' + prods.length + ')</div>' + (prods.length ? '<div class="list">' + prods.map(p => '<button class="li" data-p="' + p.id + '"><div class="grow"><div class="t">' + esc(p.name) + '</div><div class="s">' + esc(p.pend.join(' · ')) + '</div></div>' + ico('derecha', 'i-sm') + '</button>').join('') + '</div>' : '<p class="muted small">Nada pendiente.</p>');
        $('#apl', sh).onclick = () => {
          const t = num($('#toz', sh).value), c = num($('#coz', sh).value);
          if (!(t > 0) || !(c > 0)) { toast('Escribe onzas mayores que cero'); return; }
          S.settings.tragoOz = t; S.settings.copaOz = c;
          S.items.forEach(i => {
            const key = i.variant === 'Trago' ? 't' : i.variant === 'Copa' ? 'c' : '';
            if (!key) return;
            i.lines.forEach(l => { if (l.u === 'oz') l.q = key === 't' ? t : c; });
            i.pend = (i.pend || []).filter(x => !/onzas del trago|onzas de la copa/i.test(x));
          });
          saveState(); draw(); toast('Tragos y copas actualizados');
        };
        $('#goCarta', sh).onclick = () => openCarta();
        $$('[data-item]', sh).forEach(b => b.onclick = () => openItem(b.dataset.item, draw));
        $$('[data-p]', sh).forEach(b => b.onclick = () => openProduct(b.dataset.p));
      }
      draw();
    },
  });
}

// ---------- Respaldo ----------
function openRespaldo() {
  openSheet({
    title: 'Respaldo', sub: 'Una copia de todo en un archivo',
    body: '<p class="muted" style="margin-top:0">El respaldo guarda productos, carta, ventas y todos los turnos cerrados. Guárdalo en el celular o en tu WhatsApp. Al restaurar, los turnos cerrados nunca se reemplazan.</p>' +
      '<button class="btn primary block big" id="bk">' + ico('bajar') + 'Guardar respaldo</button>' +
      '<button class="btn block" id="rs" style="margin-top:12px">' + ico('subir') + 'Restaurar desde un archivo</button>',
    onMount(sh) {
      $('#bk', sh).onclick = () => saveFile(backupJson(), 'ArqueoBar-respaldo-' + isoDay() + '.json', 'application/json');
      $('#rs', sh).onclick = () => {
        if (NATIVE) Android.importBackup();
        else { const i = document.createElement('input'); i.type = 'file'; i.accept = '.json'; i.onchange = () => i.files[0].text().then(window.onBackupLoaded); i.click(); }
      };
    },
  });
}
window.onBackupLoaded = async text => {
  let data;
  try { data = JSON.parse(text); } catch (e) { toast('Ese archivo no se puede leer'); return; }
  if (!data || data.app !== 'arqueo-bar') { toast('Ese archivo no es un respaldo de Arqueo Bar'); return; }
  const when = new Date(data.at);
  if (!await confirmSheet({ title: 'Restaurar respaldo', text: 'Respaldo del ' + esc(fechaLarga(isoDay(data.at))) + ' a las ' + hora(when) + '. Se reemplaza el inventario, la carta y el turno abierto por los del archivo.', ok: 'Restaurar', danger: true })) return;
  try { restoreBackup(data); closeAllSheets(); render(); toast('Respaldo restaurado'); } catch (e) { toast(e.message); }
};

function saveFile(text, name, mime) {
  if (NATIVE) { Android.saveText(text, name, mime); return; }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type: mime }));
  a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

// ---------- Exportar a Excel (CSV con las columnas de su hoja) ----------
function exportCsv(t) {
  if (!t) { toast('Todavía no hay un turno para exportar'); return; }
  const s = t.summary || summarize(t);
  const start = t.stockOpen || t.stockStart || {};
  const end = t.stockEnd || snapshot();
  const cell = v => '"' + String(v).replace(/"/g, '""') + '"';
  const n = v => qty(v || 0, 3);
  const rows = [['Producto', 'Unidad', 'Stock inicial', 'Ingresa', 'Sale', 'Cortesía', 'Uso en el bar', 'Bajas', 'Diferencia de conteo', 'Stock final']];
  S.products.forEach(p => {
    const e = s.byProd[p.id] || {};
    const abrirDiff = (t.counts || []).filter(c => c.kind === 'abrir').reduce((a, c) => a + (c.items[p.id] ? c.items[p.id][1] - c.items[p.id][0] : 0), 0);
    rows.push([p.name, unitName(p, 2), n(start[p.id] != null ? start[p.id] : p.stock), n(e.ingresa), n(e.sale), n(e.cortesia), n(e.uso), n(e.baja), n((e.conteo || 0) - abrirDiff), n(end[p.id] != null ? end[p.id] : p.stock)]);
  });
  const csv = '﻿' + rows.map(r => r.map(cell).join(';')).join('\r\n');
  saveFile(csv, 'Inventario-' + t.id + '.csv', 'text/csv');
}

// ---------- Ajustes ----------
function openAjustes() {
  const st = S.settings;
  openSheet({
    title: 'Ajustes',
    body: '<label class="field"><span>Tu nombre</span><input class="input" id="nm" value="' + esc(st.responsable) + '" autocomplete="off"><div class="hint">Aparece como responsable en cada movimiento.</div></label>' +
      '<label class="field"><span>Nombre del bar</span><input class="input" id="bar" value="' + esc(st.bar) + '" autocomplete="off"></label>' +
      '<div class="field"><span>Tema</span><div class="seg">' + [['oscuro', 'Oscuro'], ['claro', 'Claro']].map(([k, l]) => '<button data-tema="' + k + '" aria-selected="' + (st.tema === k) + '">' + l + '</button>').join('') + '</div></div>' +
      '<div class="field"><span>Pedir el PIN</span><div class="seg">' + [[0, 'Al salir'], [1, 'Tras 1 min'], [5, 'Tras 5 min']].map(([k, l]) => '<button data-lock="' + k + '" aria-selected="' + (st.lockMin === k) + '">' + l + '</button>').join('') + '</div></div>' +
      '<button class="btn block" id="pin">' + ico('candado') + 'Cambiar PIN</button>' +
      '<button class="btn block" id="rec" style="margin-top:12px">' + ico('escudo') + 'Ver código de recuperación</button>',
    foot: '<button class="btn primary" id="sv">' + ico('check') + 'Guardar</button>',
    onMount(sh) {
      $$('[data-tema]', sh).forEach(b => b.onclick = () => { st.tema = b.dataset.tema; $$('[data-tema]', sh).forEach(x => x.setAttribute('aria-selected', x === b)); applyTheme(); saveState(); });
      $$('[data-lock]', sh).forEach(b => b.onclick = () => { st.lockMin = +b.dataset.lock; $$('[data-lock]', sh).forEach(x => x.setAttribute('aria-selected', x === b)); saveState(); });
      $('#pin', sh).onclick = () => { closeSheet(true); showPinSetup(true); };
      $('#rec', sh).onclick = () => openSheet({ title: 'Código de recuperación', body: '<p class="muted" style="margin-top:0">Si olvidas tu PIN, este código te deja crear uno nuevo. Guárdalo fuera del celular (por ejemplo, en una foto o en tu WhatsApp).</p><div class="code-box">' + esc(st.recovery) + '</div>' });
      $('#sv', sh).onclick = () => {
        const nm = $('#nm', sh).value.trim();
        if (!nm) { toast('Escribe tu nombre'); return; }
        st.responsable = nm; st.bar = $('#bar', sh).value.trim() || 'Bar';
        saveState(); closeSheet(); render(); toast('Ajustes guardados');
      };
    },
  });
}
