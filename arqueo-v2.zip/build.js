// Versión de la interfaz. Debe coincidir con UpdateManager.ASSET_BUILD (Kotlin).
// Al publicar una actualización OTA, el bundle lleva un número mayor en su manifiesto.
window.APP_BUILD = 2;
