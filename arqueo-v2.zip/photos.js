// Fotos reales incluidas en el bundle, por slug (lo genera empaquetar_actualizacion.py).
window.PHOTOS = [];
