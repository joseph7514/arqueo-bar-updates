// Actualización remota (OTA) y pantalla de Términos y permisos.

let UPD = null;   // estado de la hoja de actualización mientras está abierta

function openUpdates() {
  if (!NATIVE) {
    openSheet({
      title: 'Actualizaciones', sub: 'Interfaz v' + (window.APP_BUILD || 1),
      body: '<div class="banner info">' + ico('alerta') + '<div>Las actualizaciones a distancia solo funcionan en la app instalada en el celular, no en esta vista de prueba.</div></div>',
    });
    return;
  }
  const info = JSON.parse(Android.updateInfo());
  let found = null;    // resultado de la última búsqueda {ok, version, notas, url, sha256, hay}
  let busy = false;

  function body() {
    return '<div class="card" style="text-align:center"><div class="muted small">Versión instalada</div><div class="big-total">v' + info.version + '</div>' +
      '<div class="muted small">Arqueo Bar ' + Android.version() + '</div></div>' +
      '<label class="field" style="margin-top:16px"><span>Dirección de actualización</span>' +
      '<input class="input" id="upUrl" type="url" inputmode="url" autocomplete="off" placeholder="https://…/arqueo.json" value="' + esc(info.url) + '">' +
      '<div class="hint">La pone Joseph. Apunta al archivo con la última versión de la app.</div></label>' +
      '<button class="btn primary block" id="upCheck">' + ico('buscar') + 'Buscar actualización</button>' +
      '<div id="upResult" style="margin-top:16px"></div>' +
      (info.version > 1 ? '<button class="btn ghost block small" id="upReset" style="margin-top:20px">Volver a la versión original de la app</button>' : '');
  }
  function resultHtml() {
    if (busy) return '<div class="banner">' + ico('reloj') + '<div class="grow"><b>Trabajando…</b><div class="progress" style="margin-top:8px"><i id="upBar" style="width:0%"></i></div></div></div>';
    if (!found) return '';
    if (!found.ok) return '<div class="banner">' + ico('alerta') + '<div>No se pudo consultar: ' + esc(found.error || '') + '</div></div>';
    if (!found.hay) return '<div class="banner info">' + ico('check') + '<div>Ya tienes la última versión (v' + found.version + ').</div></div>';
    return '<div class="card"><span class="badge acc">Nueva v' + found.version + '</span>' +
      (found.notas ? '<p style="margin:10px 0 0;white-space:pre-wrap">' + esc(found.notas) + '</p>' : '') +
      '<button class="btn primary block" id="upInstall" style="margin-top:14px">' + ico('bajar') + 'Instalar v' + found.version + '</button></div>';
  }
  const sh = openSheet({
    title: 'Actualizaciones', sub: 'Trae mejoras sin reinstalar',
    body: body(),
    onClose() { UPD = null; },
    onMount(shh) {
      UPD = {
        progress(p) { const bar = $('#upBar', shh); if (bar) bar.style.width = p + '%'; },
        checked(res) { busy = false; found = res; if (res.ok) info.version = res.instalada; redraw(); },
        done(ok, msg) { busy = false; if (ok) found = null; toast(msg); redraw(); },
      };
      function redraw() {
        const cur = $('#upUrl', shh) ? $('#upUrl', shh).value : info.url;
        setSheetBody(shh, body());
        if ($('#upUrl', shh)) $('#upUrl', shh).value = cur;
        $('#upResult', shh).innerHTML = resultHtml();
        bind();
      }
      function bind() {
        $('#upCheck', shh).onclick = () => {
          const url = $('#upUrl', shh).value.trim();
          if (!/^https:\/\//i.test(url)) { toast('La dirección debe empezar con https://'); return; }
          Android.setUpdateUrl(url);
          found = null; busy = true; redraw();
          Android.checkUpdate(url);
        };
        if ($('#upInstall', shh)) $('#upInstall', shh).onclick = async () => {
          if (!await confirmSheet({ title: 'Instalar actualización', text: 'Se descarga e instala la versión ' + found.version + '. Tus datos no se tocan y la app se recarga al terminar.', ok: 'Instalar' })) return;
          busy = true; redraw();
          Android.applyUpdate(found.url, found.sha256 || '', found.version);
        };
        if ($('#upReset', shh)) $('#upReset', shh).onclick = async () => {
          if (!await confirmSheet({ title: 'Volver a la versión original', text: 'Se quita la actualización y la app vuelve a la que trae instalada. Tus datos no se tocan.', ok: 'Volver', danger: true })) return;
          Android.resetUpdate();
        };
      }
      bind();
    },
  });
  return sh;
}

window.onUpdateChecked = function (json) { let r; try { r = JSON.parse(json); } catch (e) { r = { ok: false, error: 'respuesta no válida' }; } if (UPD) UPD.checked(r); };
window.onUpdateProgress = function (pct) { if (UPD) UPD.progress(+pct); };
window.onUpdateDone = function (ok, msg) { if (UPD) UPD.done(ok === '1', msg); };

// ---------- Foto de un producto desde el celular ----------
function setPhoto(productId) {
  if (!NATIVE) { toast('Las fotos se ponen desde la app en el celular'); return; }
  Android.pickImage(productId);
}
window.onImagePicked = function (productId, dataUrl) {
  const p = PROD[productId];
  if (!p || !dataUrl) return;
  p.img = dataUrl;
  saveState();
  if (PROD_REDRAW) PROD_REDRAW();
  render();
  toast('Foto guardada');
};

// ---------- Términos y permisos ----------
const TERMS_VERSION = 1;
function accessRow(icon, t, s) { return '<div class="feature"><span class="ic">' + ico(icon) + '</span><div><b>' + esc(t) + '</b><div class="muted small">' + esc(s) + '</div></div></div>'; }
function termsHtml() {
  return '<p class="muted" style="margin-top:0">Arqueo Bar es una herramienta privada para llevar tu inventario. En resumen:</p>' +
    '<div class="section-t" style="margin-top:12px">Qué es</div>' +
    accessRow('escudo', 'Es tuya y privada', 'La usas solo tú, con PIN. No es el sistema del hotel ni se conecta con él.') +
    accessRow('inventario', 'Guarda todo en tu celular', 'Ventas, conteos y turnos quedan solo en este teléfono; no se suben a internet.') +
    accessRow('recibo', 'Es un respaldo personal', 'Sirve como evidencia de lo que vendiste. No reemplaza la factura ni el sistema del hotel.') +
    '<div class="section-t">Qué usa de tu celular</div>' +
    accessRow('botella', 'Vibración', 'Un toque corto al registrar, como confirmación.') +
    accessRow('bajar', 'Archivos', 'Solo cuando guardas un respaldo o compartes el PDF del cierre. Tú eliges el archivo.') +
    accessRow('enviar', 'Otras apps', 'Para enviarte el PDF del cierre por WhatsApp, cuando tú lo pides.') +
    accessRow('buscar', 'Internet', 'Solo si buscas una actualización de la app. El uso diario funciona sin internet.') +
    '<div class="section-t">Tu responsabilidad</div>' +
    '<p class="small muted">Los datos que registres son tu respaldo. Guarda tus respaldos y tu código de recuperación en un lugar seguro. La app te ayuda a cuadrar el bar; revisa que los conteos y precios sean correctos.</p>';
}

// required=true: hoja de la bienvenida con botón Acepto (devuelve Promise<bool>). false: solo lectura desde Más.
function openTerms(required) {
  if (!required) {
    openSheet({ full: true, title: 'Términos y permisos', sub: 'Versión ' + TERMS_VERSION, body: termsHtml() });
    return Promise.resolve(true);
  }
  return new Promise(resolve => {
    let done = false;
    openSheet({
      full: true, title: 'Términos y permisos', sub: 'Léelo antes de empezar', dismissible: false,
      body: termsHtml(),
      foot: '<button class="btn primary big block" id="acc">' + ico('check') + 'Entiendo y acepto</button>',
      onMount(sh) {
        $$('.sheet-h [data-close]', sh).forEach(b => b.remove());
        $('#acc', sh).onclick = () => { done = true; closeSheet(true); resolve(true); };
      },
      onClose() { if (!done) resolve(false); },
    });
  });
}
